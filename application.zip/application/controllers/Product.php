<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	
		public function __construct(){
		parent::__construct();
		 $this->load->model('home_model');
		
 	}
		 
		function _remap($method,$args)
	{
    	    if (method_exists($this, $method))
        { 
            $this->$method($args);
        }
    	else
        { 
            $this->index($method,$args);
        }
     
    }
	
		public function index($slug)
	{
		if($slug)
		{
			
		$tmp=$this->data['product']			=	$this->home_model->get_product_by_slug($slug);
		
		if($this->data['product'])
		{
		
		$this->data['gallery']			=	$this->home_model->get_product_gallery($tmp['pk_product_id']);
		$this->data['featured_products']=	$this->home_model->get_products();
		//$this->data['services']		=	$this->home_model->get_services();
		//$this->data['banners']		=	$this->home_model->get_banners();
		$this->data['brands']			=	$this->home_model->get_brands();
		$this->data['advertisements']	=	$this->home_model->get_advertisements('home','left_sidebar');
		$this->data['categories']		=	$this->home_model->get_service_cats();
		
		$this->load->view('public/templates/header',$this->data);
		$this->load->view('public/templates/sidebar',$this->data);
		$this->load->view('public/single_product',$this->data);
		$this->load->view('public/templates/footer',$this->data);
		}
		else
		{
			show_404();
			
		}
		
		}
		else
		{
			show_404();
		}
		
		//	var_dump($this->session);
		
	}
	
	
	
	
}
