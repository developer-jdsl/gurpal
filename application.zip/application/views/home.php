<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<h1 align="center">Home page coming soon<h1>