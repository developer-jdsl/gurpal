<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-22 09:43:51 --> Query error: Unknown column 'p.is_deleted' in 'where clause' - Invalid query: SELECT `s`.*, `b`.`category_name`, `a`.`admin_name`
FROM `tbl_services` as `s`
LEFT JOIN `tbl_business_category` as `b` ON `s`.`service_category`=`b`.`pk_category_id`
LEFT JOIN `tbl_admin` as `a` ON `s`.`fk_admin_id`=`a`.`pk_admin_id`
WHERE `p`.`is_deleted` = 0
AND `p`.`fk_admin_id` = '2'
 LIMIT 10
ERROR - 2021-04-22 09:43:58 --> Query error: Unknown column 'p.is_deleted' in 'where clause' - Invalid query: SELECT `s`.*, `b`.`category_name`, `a`.`admin_name`
FROM `tbl_services` as `s`
LEFT JOIN `tbl_business_category` as `b` ON `s`.`service_category`=`b`.`pk_category_id`
LEFT JOIN `tbl_admin` as `a` ON `s`.`fk_admin_id`=`a`.`pk_admin_id`
WHERE `p`.`is_deleted` = 0
AND `p`.`fk_admin_id` = '2'
 LIMIT 10
ERROR - 2021-04-22 09:44:02 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `tbl_brands`
WHERE `is_deleted` = '0'
ERROR - 2021-04-22 09:44:49 --> Query error: Unknown column 'pp.sdiscount_price' in 'field list' - Invalid query: SELECT `p`.`product_name`, `pp`.`product_image`, `pp`.`sdiscount_price`, `pp`.`original_price`
FROM `tbl_products` as `p`
INNER JOIN `tbl_product_pricing` as `pp` ON `p`.`pk_product_id`=`pp`.`fk_product_id`
WHERE `pp`.`is_default` = 1
AND `p`.`active` = 1
AND `is_deleted` = 0
AND `p`.`fk_admin_id` = '2'
ERROR - 2021-04-22 09:46:25 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `tbl_gst`
WHERE `is_deleted` = 1
ERROR - 2021-04-22 09:47:54 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `tbl_gst`
WHERE `is_deleted` = 1
ERROR - 2021-04-22 09:49:12 --> Query error: Unknown column 'p.is_deleted' in 'where clause' - Invalid query: SELECT `s`.*, `b`.`category_name`, `a`.`admin_name`
FROM `tbl_services` as `s`
LEFT JOIN `tbl_business_category` as `b` ON `s`.`service_category`=`b`.`pk_category_id`
LEFT JOIN `tbl_admin` as `a` ON `s`.`fk_admin_id`=`a`.`pk_admin_id`
WHERE `p`.`is_deleted` = 0
AND `p`.`fk_admin_id` = '2'
 LIMIT 10
ERROR - 2021-04-22 09:49:20 --> Query error: Unknown column 'p.is_deleted' in 'where clause' - Invalid query: SELECT `s`.*, `b`.`category_name`, `a`.`admin_name`
FROM `tbl_services` as `s`
LEFT JOIN `tbl_business_category` as `b` ON `s`.`service_category`=`b`.`pk_category_id`
LEFT JOIN `tbl_admin` as `a` ON `s`.`fk_admin_id`=`a`.`pk_admin_id`
WHERE `p`.`is_deleted` = 0
AND `p`.`fk_admin_id` = '2'
 LIMIT 10
ERROR - 2021-04-22 09:50:05 --> Query error: Unknown column 'p.is_deleted' in 'where clause' - Invalid query: SELECT `s`.*, `b`.`category_name`, `a`.`admin_name`
FROM `tbl_services` as `s`
LEFT JOIN `tbl_business_category` as `b` ON `s`.`service_category`=`b`.`pk_category_id`
LEFT JOIN `tbl_admin` as `a` ON `s`.`fk_admin_id`=`a`.`pk_admin_id`
WHERE `p`.`is_deleted` = 0
AND `p`.`fk_admin_id` = '2'
 LIMIT 10
ERROR - 2021-04-22 13:00:09 --> Severity: Notice --> Undefined index: admin_name E:\xampp\htdocs\gurpal\application\views\admin\templates\topbar.php 184
ERROR - 2021-04-22 13:00:57 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\views\admin\templates\topbar.php 184
ERROR - 2021-04-22 13:02:03 --> Severity: error --> Exception: Cannot use object of type stdClass as array E:\xampp\htdocs\gurpal\application\views\admin\templates\topbar.php 184
