<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-27 08:51:10 --> Severity: Compile Error --> Cannot redeclare Admin_model::check_package_id() E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 1844
ERROR - 2021-04-27 14:04:08 --> 404 Page Not Found: Admin/%7B%7BLOGO%7D%7D
ERROR - 2021-04-27 14:04:08 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 14:04:08 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 14:04:08 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 14:04:08 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 14:04:37 --> 404 Page Not Found: Admin/%7B%7BLOGO%7D%7D
ERROR - 2021-04-27 14:04:37 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 14:04:37 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 14:04:37 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 14:04:37 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 15:34:09 --> 404 Page Not Found: Admin/%7B%7BLOGO%7D%7D
ERROR - 2021-04-27 15:34:09 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 15:34:09 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 15:34:09 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
ERROR - 2021-04-27 15:34:09 --> 404 Page Not Found: Admin/%7B%7BSITE_URL%7D%7Dpublic
