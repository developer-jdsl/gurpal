<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-26 08:16:53 --> 404 Page Not Found: Authentication/forgot_password
ERROR - 2021-04-26 09:05:19 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:05:19 --> Severity: Warning --> Illegal string offset 'to' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:05:19 --> Severity: Warning --> Illegal string offset 'subject' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 113
ERROR - 2021-04-26 09:05:19 --> Severity: Warning --> Illegal string offset 'message' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 114
ERROR - 2021-04-26 09:05:19 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 115
ERROR - 2021-04-26 09:06:08 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:06:08 --> Severity: Warning --> Illegal string offset 'to' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:06:08 --> Severity: Warning --> Illegal string offset 'subject' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 113
ERROR - 2021-04-26 09:06:08 --> Severity: Warning --> Illegal string offset 'message' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 114
ERROR - 2021-04-26 09:06:08 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 115
ERROR - 2021-04-26 09:07:16 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:07:16 --> Severity: Warning --> Illegal string offset 'to' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:07:16 --> Severity: Warning --> Illegal string offset 'subject' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 113
ERROR - 2021-04-26 09:07:16 --> Severity: Warning --> Illegal string offset 'message' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 114
ERROR - 2021-04-26 09:07:16 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 115
ERROR - 2021-04-26 09:09:18 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:09:18 --> Severity: Warning --> Illegal string offset 'to' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:09:18 --> Severity: Warning --> Illegal string offset 'subject' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 113
ERROR - 2021-04-26 09:09:18 --> Severity: Warning --> Illegal string offset 'message' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 114
ERROR - 2021-04-26 09:09:18 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 115
ERROR - 2021-04-26 09:09:32 --> Severity: Warning --> Illegal string offset 'to' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:09:32 --> Severity: Warning --> Illegal string offset 'subject' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 113
ERROR - 2021-04-26 09:09:32 --> Severity: Warning --> Illegal string offset 'message' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 114
ERROR - 2021-04-26 09:09:32 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 115
ERROR - 2021-04-26 09:09:38 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:09:38 --> Severity: Warning --> Illegal string offset 'to' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 09:09:38 --> Severity: Warning --> Illegal string offset 'subject' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 113
ERROR - 2021-04-26 09:09:38 --> Severity: Warning --> Illegal string offset 'message' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 114
ERROR - 2021-04-26 09:09:38 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 115
ERROR - 2021-04-26 11:11:24 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 11:11:24 --> Severity: Warning --> Illegal string offset 'to' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 11:11:24 --> Severity: Warning --> Illegal string offset 'subject' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 113
ERROR - 2021-04-26 11:11:24 --> Severity: Warning --> Illegal string offset 'message' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 114
ERROR - 2021-04-26 11:11:24 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 115
ERROR - 2021-04-26 11:12:27 --> Severity: Warning --> Missing argument 1 for Authentication_model::check_reset_hash(), called in E:\xampp\htdocs\gurpal\application\controllers\Authentication.php on line 83 and defined E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 137
ERROR - 2021-04-26 11:12:27 --> Severity: Notice --> Undefined variable: hash E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 141
ERROR - 2021-04-26 11:12:27 --> Severity: error --> Exception: Call to undefined function userdata() E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 87
ERROR - 2021-04-26 11:12:51 --> Severity: error --> Exception: Call to undefined function userdata() E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 87
ERROR - 2021-04-26 11:17:59 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 97
ERROR - 2021-04-26 11:18:20 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 96
ERROR - 2021-04-26 11:18:22 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 96
ERROR - 2021-04-26 11:18:47 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 96
ERROR - 2021-04-26 11:18:53 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 96
ERROR - 2021-04-26 11:19:19 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 96
ERROR - 2021-04-26 11:20:32 --> Severity: Warning --> Missing argument 1 for Authentication::reset_password(), called in E:\xampp\htdocs\gurpal\system\core\CodeIgniter.php on line 532 and defined E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 78
ERROR - 2021-04-26 11:20:32 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 81
ERROR - 2021-04-26 11:20:45 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 11:20:45 --> Severity: Warning --> Illegal string offset 'to' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 112
ERROR - 2021-04-26 11:20:45 --> Severity: Warning --> Illegal string offset 'subject' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 113
ERROR - 2021-04-26 11:20:45 --> Severity: Warning --> Illegal string offset 'message' E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 114
ERROR - 2021-04-26 11:20:45 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 115
ERROR - 2021-04-26 11:21:20 --> Severity: Warning --> Missing argument 1 for Authentication::reset_password(), called in E:\xampp\htdocs\gurpal\system\core\CodeIgniter.php on line 532 and defined E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 78
ERROR - 2021-04-26 11:21:20 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 81
ERROR - 2021-04-26 11:23:35 --> Severity: Warning --> Missing argument 1 for Authentication::reset_password(), called in E:\xampp\htdocs\gurpal\system\core\CodeIgniter.php on line 532 and defined E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 78
ERROR - 2021-04-26 11:23:35 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 81
ERROR - 2021-04-26 11:24:48 --> Severity: Warning --> Missing argument 1 for Authentication::reset_password(), called in E:\xampp\htdocs\gurpal\system\core\CodeIgniter.php on line 532 and defined E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 78
ERROR - 2021-04-26 11:24:48 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 81
ERROR - 2021-04-26 11:46:31 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 85
ERROR - 2021-04-26 11:47:30 --> Severity: Warning --> Missing argument 1 for Authentication::reset_password(), called in E:\xampp\htdocs\gurpal\system\core\CodeIgniter.php on line 532 and defined E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 78
ERROR - 2021-04-26 11:47:30 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 82
ERROR - 2021-04-26 11:51:32 --> Severity: Warning --> Missing argument 1 for Authentication::reset_password(), called in E:\xampp\htdocs\gurpal\system\core\CodeIgniter.php on line 532 and defined E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 78
ERROR - 2021-04-26 11:51:32 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 82
ERROR - 2021-04-26 12:08:48 --> 404 Page Not Found: Admin/profile
ERROR - 2021-04-26 12:16:06 --> Severity: Compile Error --> Cannot redeclare Admin::update_admin() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 4438
ERROR - 2021-04-26 12:16:50 --> 404 Page Not Found: 
ERROR - 2021-04-26 12:16:57 --> 404 Page Not Found: 
ERROR - 2021-04-26 12:18:23 --> 404 Page Not Found: 
ERROR - 2021-04-26 12:18:36 --> 404 Page Not Found: 
ERROR - 2021-04-26 12:43:42 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 4495
ERROR - 2021-04-26 12:43:42 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 4503
ERROR - 2021-04-26 12:43:42 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 4504
ERROR - 2021-04-26 13:16:51 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:17:56 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:18:22 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:18:22 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:31:43 --> Query error: Unknown column 'p.fk_admin_id' in 'on clause' - Invalid query: SELECT `a`.*, `ap`.*
FROM `tbl_admin` as `a`
LEFT JOIN `tbl_admin_profile` as `ap` ON `a`.`pk_admin_id`=`ap`.`fk_admin_id`
LEFT JOIN `tbl_packages` as `p` ON `a`.`pk_admin_id`=`p`.`fk_admin_id`
WHERE `a`.`admin_email` = 'akshay@jdslsolutions.com'
AND `a`.`admin_password` = '15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225'
ERROR - 2021-04-26 13:32:41 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:32:41 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:32:44 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:32:44 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:35:35 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:35:35 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:40:40 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:40:40 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:53:30 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 82
ERROR - 2021-04-26 13:54:00 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:54:00 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:54:03 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:54:03 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:54:06 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:54:06 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:55:45 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:55:45 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:55:47 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:55:47 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:55:53 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:55:53 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:57:22 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:57:22 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:57:24 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:57:24 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:57:29 --> Severity: Notice --> Undefined property: stdClass::$package_products E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 13:57:29 --> Severity: Notice --> Undefined property: stdClass::$package_services E:\xampp\htdocs\gurpal\application\views\admin\templates\header.php 32
ERROR - 2021-04-26 14:06:20 --> Severity: error --> Exception: Using $this when not in object context E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 70
ERROR - 2021-04-26 14:06:45 --> Severity: error --> Exception: Cannot use object of type stdClass as array E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 74
ERROR - 2021-04-26 14:07:06 --> Severity: Notice --> Undefined index: p.package_category E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 74
ERROR - 2021-04-26 14:07:06 --> Severity: Notice --> Undefined index: p.package_products E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 74
ERROR - 2021-04-26 14:07:06 --> Severity: Notice --> Undefined index: p.package_services E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 74
ERROR - 2021-04-26 14:15:48 --> Severity: error --> Exception: syntax error, unexpected 's' (T_STRING) E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 67
ERROR - 2021-04-26 14:42:19 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING) E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1522
ERROR - 2021-04-26 14:42:31 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING) E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2873
ERROR - 2021-04-26 14:45:58 --> Query error: Column 'cross_sell' cannot be null - Invalid query: INSERT INTO `tbl_products` (`product_name`, `product_sku`, `product_description`, `product_brand`, `product_specifications`, `cross_sell`, `meta_title`, `meta_keyword`, `meta_description`, `is_cod`, `ordering`, `fk_gst_id`, `fk_admin_id`, `product_category`, `active`, `created_by`) VALUES ('Product', 'Product', 'Product', '1', 'Product', NULL, 'Product', 'Product', '', '1', '', '2', '7', '1', '1', '7')
ERROR - 2021-04-26 14:49:42 --> Query error: Column 'cross_sell' cannot be null - Invalid query: INSERT INTO `tbl_products` (`product_name`, `product_sku`, `product_description`, `product_brand`, `product_specifications`, `cross_sell`, `meta_title`, `meta_keyword`, `meta_description`, `is_cod`, `ordering`, `fk_gst_id`, `fk_admin_id`, `product_category`, `active`, `created_by`) VALUES ('111', 'qqq', 'qqq', '1', 'qqq', NULL, '', '', '', '1', '', '1', '7', '1', '1', '7')
ERROR - 2021-04-26 14:50:26 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `tbl_color`
WHERE `is_deleted` = 1
ERROR - 2021-04-26 14:51:55 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `tbl_size`
WHERE `is_deleted` = 0
ERROR - 2021-04-26 14:55:40 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `tbl_color`
WHERE `is_deleted` = 0
AND `active` = 1
ERROR - 2021-04-26 14:56:23 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `tbl_size`
WHERE `is_deleted` = 0
AND `active` = 1
