<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-21 06:30:44 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-21 06:30:44 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-21 06:30:44 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-21 06:30:44 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-21 06:30:44 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-21 06:31:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:31:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:38:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:42:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:42:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:42:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:42:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:42:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:42:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:42:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:42:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:43:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:44:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:45:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:47:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:48:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:48:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:48:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:48:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:49:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:50:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:50:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:50:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:50:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:50:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:50:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:50:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:50:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:51:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:52:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:52:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:52:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:52:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:53:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:53:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:53:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:53:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:53:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:53:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:53:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:53:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:54:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:54:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:54:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:54:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:54:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:54:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:54:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:54:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-21 06:55:28 --> 404 Page Not Found: Admin/login.html
ERROR - 2021-04-21 07:04:37 --> Severity: error --> Exception: syntax error, unexpected '}' E:\xampp\htdocs\gurpal\application\controllers\Admin.php 31
ERROR - 2021-04-21 07:04:54 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 48
ERROR - 2021-04-21 07:30:08 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-21 07:30:08 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-21 07:30:08 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-21 07:30:08 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-21 07:30:08 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-21 07:31:29 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-21 07:31:29 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-21 07:31:29 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-21 07:31:29 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-21 07:31:29 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-21 07:31:59 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-21 07:31:59 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-21 07:31:59 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-21 07:31:59 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-21 07:31:59 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-21 07:33:15 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-21 07:33:15 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-21 07:33:15 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-21 07:33:15 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-21 07:33:15 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-21 07:33:43 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-21 08:29:21 --> 404 Page Not Found: Admin/services
ERROR - 2021-04-21 09:00:36 --> Severity: Compile Error --> Cannot redeclare Admin::edit_product() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2908
ERROR - 2021-04-21 09:00:38 --> Severity: Compile Error --> Cannot redeclare Admin::edit_product() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2908
ERROR - 2021-04-21 10:39:52 --> Severity: error --> Exception: Call to undefined method Admin_model::get_services() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2756
ERROR - 2021-04-21 10:40:48 --> Severity: error --> Exception: Call to undefined method Admin_model::get_service_cats() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2816
ERROR - 2021-04-21 11:18:49 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\gurpal\application\views\admin\services\add_service.php 51
ERROR - 2021-04-21 11:18:49 --> Severity: Notice --> Undefined variable: row E:\xampp\htdocs\gurpal\application\views\admin\services\add_service.php 52
ERROR - 2021-04-21 11:22:36 --> Query error: Unknown column 'meta_keyword' in 'field list' - Invalid query: INSERT INTO `tbl_services` (`service_name`, `service_pricing`, `service_description`, `service_features`, `meta_title`, `meta_keyword`, `meta_description`, `ordering`, `fk_gst_id`, `fk_admin_id`, `service_category`, `active`, `created_by`) VALUES ('AKSHAY CATERERS', '500 per plate', 'AKSHAY CATERERS', 'AKSHAY CATERERS', 'AKSHAY CATERERS', 'AKSHAY CATERERS', 'AKSHAY CATERERS', '', '1', '2', '1', '1', '1')
ERROR - 2021-04-21 11:23:34 --> Query error: Unknown column 'service_banner' in 'field list' - Invalid query: INSERT INTO `tbl_services` (`service_name`, `service_pricing`, `service_description`, `service_features`, `meta_title`, `meta_keywords`, `meta_description`, `ordering`, `fk_gst_id`, `fk_admin_id`, `service_category`, `active`, `created_by`, `service_banner`) VALUES ('AKSHAY CATERERS', '500 per plate', 'AKSHAY CATERERS', 'AKSHAY CATERERS', 'AKSHAY CATERERS', 'AKSHAY CATERERS', 'AKSHAY CATERERS', '', '1', '2', '1', '1', '1', 'akshay-caterers.jpg')
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$service_banner E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2762
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$service_name E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2762
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$service_description E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2763
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$service_price E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2764
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2768
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2771
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$service_banner E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2762
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$service_name E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2762
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$service_description E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2763
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$service_price E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2764
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2768
ERROR - 2021-04-21 11:24:36 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2771
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$service_banners E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2762
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$service_name E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2762
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$service_description E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2763
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$service_price E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2764
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2768
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2771
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$service_banners E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2762
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$service_name E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2762
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$service_description E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2763
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$service_price E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2764
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2768
ERROR - 2021-04-21 11:25:23 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2771
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$service_banners E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2763
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$service_name E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2763
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$service_description E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2764
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$service_price E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2765
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2769
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2772
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$service_banners E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2763
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$service_name E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2763
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$service_description E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2764
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$service_price E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2765
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2769
ERROR - 2021-04-21 11:26:37 --> Severity: Notice --> Undefined property: stdClass::$pk_service_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2772
ERROR - 2021-04-21 11:27:00 --> Severity: Notice --> Undefined property: stdClass::$service_price E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2765
ERROR - 2021-04-21 11:27:15 --> Severity: Notice --> Undefined property: stdClass::$service_price E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2764
ERROR - 2021-04-21 11:27:35 --> Severity: Notice --> Undefined index: service_banner E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 76
ERROR - 2021-04-21 11:27:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 146
ERROR - 2021-04-21 11:28:42 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 146
ERROR - 2021-04-21 11:29:32 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 146
ERROR - 2021-04-21 11:30:29 --> Severity: Notice --> Undefined variable: results E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 49
ERROR - 2021-04-21 11:30:29 --> Severity: Notice --> Undefined variable: results E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 50
ERROR - 2021-04-21 11:30:29 --> Severity: Notice --> Undefined variable: results E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 65
ERROR - 2021-04-21 11:30:29 --> Severity: Notice --> Undefined variable: results E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 76
ERROR - 2021-04-21 11:30:29 --> Severity: Notice --> Undefined variable: results E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 93
ERROR - 2021-04-21 11:30:29 --> Severity: Notice --> Undefined variable: results E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 104
ERROR - 2021-04-21 11:30:29 --> Severity: Notice --> Undefined variable: results E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 146
ERROR - 2021-04-21 11:31:21 --> Severity: Notice --> Undefined index: service_pricing E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 91
ERROR - 2021-04-21 11:33:55 --> Severity: Notice --> Undefined index: service_banner E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 1294
ERROR - 2021-04-21 11:33:55 --> Severity: Warning --> unlink(.uploads/service/): No such file or directory E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 1294
ERROR - 2021-04-21 13:16:21 --> Severity: Notice --> Undefined index: brand_name E:\xampp\htdocs\gurpal\application\views\admin\procategory\procategory.php 48
ERROR - 2021-04-21 13:19:10 --> The upload path does not appear to be valid.
ERROR - 2021-04-21 13:19:10 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 3191
ERROR - 2021-04-21 13:19:10 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 1339
ERROR - 2021-04-21 13:19:10 --> Query error: Unknown column 'created_by' in 'field list' - Invalid query: INSERT INTO `tbl_product_category` (`category_name`, `parent_category`, `meta_title`, `meta_keywords`, `meta_description`, `ordering`, `active`, `created_by`, `category_slug`) VALUES ('CAT1', '1', 'CAT1', 'CAT1', 'CAT1', '', '1', '1', 'cat1')
ERROR - 2021-04-21 13:21:27 --> The upload path does not appear to be valid.
ERROR - 2021-04-21 13:21:27 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 3191
ERROR - 2021-04-21 13:21:28 --> Severity: Notice --> Undefined variable: slug E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 1343
ERROR - 2021-04-21 13:24:17 --> Severity: Warning --> Illegal string offset 'brand_name' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 247
ERROR - 2021-04-21 13:24:17 --> Severity: Warning --> Illegal string offset 'active' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 247
ERROR - 2021-04-21 13:24:17 --> Severity: Warning --> Illegal string offset 'brand_name' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 252
ERROR - 2021-04-21 13:24:17 --> Severity: Warning --> Illegal string offset 'pk_brand_id' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 253
ERROR - 2021-04-21 13:24:17 --> Severity: Warning --> Illegal string offset 'pk_brand_id' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 255
ERROR - 2021-04-21 13:25:39 --> The upload path does not appear to be valid.
ERROR - 2021-04-21 13:25:39 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 3311
ERROR - 2021-04-21 13:25:39 --> Severity: Warning --> Illegal string offset 'brand_name' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 247
ERROR - 2021-04-21 13:25:39 --> Severity: Warning --> Illegal string offset 'active' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 247
ERROR - 2021-04-21 13:25:39 --> Severity: Warning --> Illegal string offset 'brand_name' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 252
ERROR - 2021-04-21 13:25:39 --> Severity: Warning --> Illegal string offset 'pk_brand_id' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 253
ERROR - 2021-04-21 13:25:39 --> Severity: Warning --> Illegal string offset 'pk_brand_id' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 255
ERROR - 2021-04-21 13:25:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\gurpal\system\core\Exceptions.php:271) E:\xampp\htdocs\gurpal\system\helpers\url_helper.php 564
ERROR - 2021-04-21 13:27:18 --> The upload path does not appear to be valid.
ERROR - 2021-04-21 13:27:18 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 3311
ERROR - 2021-04-21 13:28:38 --> The upload path does not appear to be valid.
ERROR - 2021-04-21 13:28:38 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 3311
ERROR - 2021-04-21 13:29:35 --> The upload path does not appear to be valid.
ERROR - 2021-04-21 13:29:35 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 3311
ERROR - 2021-04-21 15:20:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\xampp\htdocs\gurpal\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-04-21 15:20:30 --> Unable to connect to the database
