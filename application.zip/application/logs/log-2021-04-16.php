<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-16 05:37:16 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-16 05:37:16 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-16 05:37:16 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-16 05:37:16 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-16 05:37:16 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-16 06:36:03 --> Severity: error --> Exception: Call to undefined method Admin_model::get_banners() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 28
ERROR - 2021-04-16 06:36:44 --> Severity: error --> Exception: syntax error, unexpected '{', expecting function (T_FUNCTION) E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 10
ERROR - 2021-04-16 06:36:51 --> Severity: Notice --> Undefined variable: data E:\xampp\htdocs\gurpal\application\controllers\Admin.php 31
ERROR - 2021-04-16 06:36:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:36:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:36:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:36:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:37:32 --> Severity: 4096 --> Object of class Admin could not be converted to string E:\xampp\htdocs\gurpal\application\controllers\Admin.php 31
ERROR - 2021-04-16 06:37:32 --> Severity: Notice --> Undefined variable:  E:\xampp\htdocs\gurpal\application\controllers\Admin.php 31
ERROR - 2021-04-16 06:37:32 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 31
ERROR - 2021-04-16 06:37:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:37:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:37:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:37:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:37:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:37:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:37:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 06:37:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:08:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:08:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:08:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:08:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:10:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:10:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:10:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:10:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:12:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:12:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:12:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 07:12:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:23:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:23:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:23:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:23:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:23:24 --> Severity: Notice --> Undefined variable: states E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 18
ERROR - 2021-04-16 08:23:24 --> Severity: error --> Exception: Call to a member function get() on null E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 18
ERROR - 2021-04-16 08:23:53 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file E:\xampp\htdocs\gurpal\application\controllers\Admin.php 47
ERROR - 2021-04-16 08:24:13 --> Severity: Notice --> Undefined variable: states E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 18
ERROR - 2021-04-16 08:24:13 --> Severity: error --> Exception: Call to a member function get() on null E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 18
ERROR - 2021-04-16 08:24:30 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2021-04-16 08:25:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:25:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:25:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:25:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:25:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:25:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:25:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:25:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:34:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:34:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:34:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:34:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:35:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:35:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:35:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 08:35:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:13:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:13:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:13:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:13:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:13:43 --> Severity: Notice --> Undefined property: Admin::$form_validation E:\xampp\htdocs\gurpal\application\controllers\Admin.php 51
ERROR - 2021-04-16 09:13:43 --> Severity: error --> Exception: Call to a member function set_rules() on null E:\xampp\htdocs\gurpal\application\controllers\Admin.php 51
ERROR - 2021-04-16 09:15:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:15:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:15:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:15:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:15:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:15:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:15:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:15:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:15:39 --> Severity: Notice --> Undefined property: Admin::$form_validation E:\xampp\htdocs\gurpal\application\controllers\Admin.php 51
ERROR - 2021-04-16 09:15:39 --> Severity: error --> Exception: Call to a member function set_rules() on null E:\xampp\htdocs\gurpal\application\controllers\Admin.php 51
ERROR - 2021-04-16 09:16:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:16:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:16:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:16:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:18:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:19:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:19:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:19:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:19:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:20:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:20:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:20:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:20:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:27:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:27:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:27:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:27:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:27:58 --> Severity: Notice --> Undefined property: Admin::$admin_model E:\xampp\htdocs\gurpal\application\controllers\Admin.php 75
ERROR - 2021-04-16 09:27:58 --> Severity: error --> Exception: Call to a member function add_state() on null E:\xampp\htdocs\gurpal\application\controllers\Admin.php 75
ERROR - 2021-04-16 09:28:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:28:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:28:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:28:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:28:19 --> Severity: Notice --> Undefined property: Admin::$Admin_model E:\xampp\htdocs\gurpal\application\controllers\Admin.php 42
ERROR - 2021-04-16 09:28:19 --> Severity: error --> Exception: Call to a member function get_states() on null E:\xampp\htdocs\gurpal\application\controllers\Admin.php 42
ERROR - 2021-04-16 09:28:45 --> Severity: Notice --> Undefined index: pk_admin_id E:\xampp\htdocs\gurpal\application\views\admin\states\states.php 46
ERROR - 2021-04-16 09:28:45 --> Severity: Notice --> Undefined index: pk_admin_id E:\xampp\htdocs\gurpal\application\views\admin\states\states.php 47
ERROR - 2021-04-16 09:28:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:28:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:28:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:28:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:29:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:29:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:29:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:29:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:33:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:33:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:33:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:33:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:34:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:35:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:35:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:35:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:35:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:35:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:35:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:35:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:35:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:36:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:36:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:36:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:36:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:50:02 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 50
ERROR - 2021-04-16 09:50:23 --> Severity: Compile Error --> Cannot redeclare Admin_model::add_state() E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 43
ERROR - 2021-04-16 09:50:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:50:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:50:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:50:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:53:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:53:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:53:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:53:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'state_name' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 38
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'active' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 39
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 40
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 41
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'state_name' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 38
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'active' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 39
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 40
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 41
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'state_name' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 38
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'active' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 39
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 40
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 41
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'state_name' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 38
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'active' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 39
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 40
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 41
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'state_name' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 38
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'active' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 39
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 40
ERROR - 2021-04-16 09:53:15 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\states\edit_state.php 41
ERROR - 2021-04-16 09:53:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:53:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:53:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:53:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:57:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:57:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:57:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:57:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:57:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:57:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:57:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:57:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:58:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 09:59:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:01:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:01:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:01:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:01:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:01:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:01:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:01:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:01:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:03:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:03:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:03:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:03:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:04:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:08:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:11:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:11:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:11:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:11:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:11:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:11:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:11:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:11:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:12:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:15:57 --> Severity: error --> Exception: syntax error, unexpected 'fucntion' (T_STRING), expecting variable (T_VARIABLE) E:\xampp\htdocs\gurpal\application\controllers\Admin.php 225
ERROR - 2021-04-16 10:16:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:36 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 64
ERROR - 2021-04-16 10:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:17:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:17:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:17:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:17:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:17:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:17:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:17:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:17:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:18:06 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 64
ERROR - 2021-04-16 10:18:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:18:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:18:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:18:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:26 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 64
ERROR - 2021-04-16 10:19:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:49 --> 404 Page Not Found: Admin/colors
ERROR - 2021-04-16 10:19:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:19:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:20:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:20:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:20:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:20:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:20:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:20:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:20:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 10:20:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:04:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:04:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:04:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:04:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:04:43 --> 404 Page Not Found: Admin/cities
ERROR - 2021-04-16 11:23:05 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-16 11:23:05 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-16 11:23:06 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-16 11:23:06 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-16 11:23:06 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-16 11:24:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:24:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:36:51 --> Severity: Compile Error --> Cannot redeclare Admin::edit_state() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 314
ERROR - 2021-04-16 11:36:56 --> Severity: Compile Error --> Cannot redeclare Admin::edit_state() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 314
ERROR - 2021-04-16 11:37:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:37:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:37:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:37:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:37:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:37:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:37:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 11:37:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:21:42 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) E:\xampp\htdocs\gurpal\application\controllers\Admin.php 400
ERROR - 2021-04-16 12:21:55 --> Severity: Compile Error --> Cannot redeclare Admin_model::remove_state() E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 159
ERROR - 2021-04-16 12:22:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:22:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:21 --> Severity: Notice --> Undefined index: fk_state_id E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 147
ERROR - 2021-04-16 12:23:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:23:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:24:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 12:25:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:07:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:08:45 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-16 13:08:45 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-16 13:08:45 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-16 13:08:45 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-16 13:08:45 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-16 13:11:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:11:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:11:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:11:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 13:25:49 --> Severity: error --> Exception: Call to undefined method Admin_model::get_brands() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 503
ERROR - 2021-04-16 13:45:16 --> Severity: Compile Error --> Cannot redeclare Admin_model::add_city() E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 220
ERROR - 2021-04-16 14:34:23 --> Severity: Compile Error --> Cannot redeclare Admin::update_city() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 591
ERROR - 2021-04-16 14:34:25 --> Severity: Compile Error --> Cannot redeclare Admin::update_city() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 591
ERROR - 2021-04-16 14:34:25 --> Severity: Compile Error --> Cannot redeclare Admin::update_city() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 591
ERROR - 2021-04-16 14:34:25 --> Severity: Compile Error --> Cannot redeclare Admin::update_city() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 591
ERROR - 2021-04-16 14:34:26 --> Severity: Compile Error --> Cannot redeclare Admin::update_city() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 591
ERROR - 2021-04-16 15:01:31 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ')' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 221
ERROR - 2021-04-16 15:01:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:01:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:01:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:01:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:02:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:02:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:02:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:02:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:35 --> 404 Page Not Found: Admin/add_row
ERROR - 2021-04-16 15:32:48 --> Severity: Notice --> Undefined property: Admin::$data E:\xampp\htdocs\gurpal\application\controllers\Admin.php 530
ERROR - 2021-04-16 15:32:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:32:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:33:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:33:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:33:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:33:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:34:07 --> Severity: Notice --> Undefined index: created_by E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 221
ERROR - 2021-04-16 15:34:07 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `tbl_brands` (`brand_name`, `brand_image`, `active`, `created_by`) VALUES ('Nestle', 'nestle.jpg', '1', NULL)
ERROR - 2021-04-16 15:35:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:35:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:35:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:35:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:35:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:35:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:35:36 --> 404 Page Not Found: Uploads/brands
ERROR - 2021-04-16 15:35:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:35:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:35:43 --> 404 Page Not Found: Uploads/brands
ERROR - 2021-04-16 15:35:46 --> 404 Page Not Found: Uploads/brands
ERROR - 2021-04-16 15:35:48 --> 404 Page Not Found: Uploads/brands
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:04 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\brands\edit_brand.php 44
ERROR - 2021-04-16 15:36:04 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\brands\edit_brand.php 45
ERROR - 2021-04-16 15:36:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:58 --> 404 Page Not Found: Uploads/brands
ERROR - 2021-04-16 15:36:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:36:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:42 --> Severity: Notice --> Undefined index: brand_image	 E:\xampp\htdocs\gurpal\application\views\admin\brands\edit_brand.php 35
ERROR - 2021-04-16 15:37:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-16 15:37:55 --> 404 Page Not Found: Admin/img
