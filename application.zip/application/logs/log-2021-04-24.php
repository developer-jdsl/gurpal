<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-24 08:09:11 --> 404 Page Not Found: Admin/packages
ERROR - 2021-04-24 09:44:56 --> Severity: Compile Error --> Cannot redeclare Admin::delete_size() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 4325
ERROR - 2021-04-24 09:48:06 --> Query error: Column 'package_services' cannot be null - Invalid query: INSERT INTO `tbl_packages` (`package_name`, `package_description`, `package_validity`, `package_products`, `package_services`, `show_price`, `show_features`, `active`) VALUES ('FREE', '5 products + 5 services for 30 days', '1', '5', NULL, '0', '0', '1')
ERROR - 2021-04-24 09:54:23 --> Severity: Notice --> Undefined index: status E:\xampp\htdocs\gurpal\application\views\admin\packages\edit_package.php 83
ERROR - 2021-04-24 09:54:23 --> Severity: Notice --> Undefined index: status E:\xampp\htdocs\gurpal\application\views\admin\packages\edit_package.php 84
ERROR - 2021-04-24 09:54:28 --> Query error: Unknown column 'pk_package_id' in 'where clause' - Invalid query: UPDATE `tbl_size` SET `package_name` = 'FREE', `package_description` = '5 products + 5 services for 30 days', `package_validity` = '1', `package_products` = '5', `package_services` = '5', `show_price` = '1', `show_features` = '0', `active` = '1'
WHERE `pk_package_id` = '1'
ERROR - 2021-04-24 09:55:18 --> Severity: Notice --> Undefined index: status E:\xampp\htdocs\gurpal\application\views\admin\packages\edit_package.php 83
ERROR - 2021-04-24 09:55:18 --> Severity: Notice --> Undefined index: status E:\xampp\htdocs\gurpal\application\views\admin\packages\edit_package.php 84
ERROR - 2021-04-24 09:56:02 --> Severity: Notice --> Undefined index: status E:\xampp\htdocs\gurpal\application\views\admin\packages\edit_package.php 83
ERROR - 2021-04-24 09:56:02 --> Severity: Notice --> Undefined index: status E:\xampp\htdocs\gurpal\application\views\admin\packages\edit_package.php 84
ERROR - 2021-04-24 09:56:08 --> Severity: Notice --> Undefined index: status E:\xampp\htdocs\gurpal\application\views\admin\packages\edit_package.php 83
ERROR - 2021-04-24 09:56:08 --> Severity: Notice --> Undefined index: status E:\xampp\htdocs\gurpal\application\views\admin\packages\edit_package.php 84
ERROR - 2021-04-24 10:07:37 --> Query error: Unknown column 'is_active' in 'where clause' - Invalid query: SELECT *
FROM `tbl_packages`
WHERE `is_deleted` = 0
AND `is_active` = 1
ERROR - 2021-04-24 10:07:51 --> Severity: Notice --> Undefined variable: packages E:\xampp\htdocs\gurpal\application\views\admin\admins\add_admin.php 49
ERROR - 2021-04-24 10:07:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\admins\add_admin.php 49
ERROR - 2021-04-24 10:08:42 --> Severity: Notice --> Undefined variable: packages E:\xampp\htdocs\gurpal\application\views\admin\admins\add_admin.php 49
ERROR - 2021-04-24 10:08:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\admins\add_admin.php 49
ERROR - 2021-04-24 10:10:47 --> Severity: Notice --> Undefined variable: packages E:\xampp\htdocs\gurpal\application\views\admin\admins\add_admin.php 47
ERROR - 2021-04-24 10:10:47 --> Severity: Notice --> Undefined variable: packages E:\xampp\htdocs\gurpal\application\views\admin\admins\add_admin.php 50
ERROR - 2021-04-24 10:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\admins\add_admin.php 50
ERROR - 2021-04-24 10:17:48 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 4027
ERROR - 2021-04-24 10:17:48 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 4028
ERROR - 2021-04-24 10:19:45 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 4028
ERROR - 2021-04-24 14:13:07 --> 404 Page Not Found: Admin/verify_email
ERROR - 2021-04-24 14:14:26 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\gurpal\system\libraries\Email.php 1902
ERROR - 2021-04-24 14:16:27 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\gurpal\system\libraries\Email.php 1902
ERROR - 2021-04-24 14:19:36 --> Severity: Warning --> Missing argument 1 for Verify_email::verify(), called in E:\xampp\htdocs\gurpal\system\core\CodeIgniter.php on line 532 and defined E:\xampp\htdocs\gurpal\application\controllers\Verify_email.php 13
ERROR - 2021-04-24 14:19:36 --> Severity: Notice --> Undefined variable: passcode E:\xampp\htdocs\gurpal\application\controllers\Verify_email.php 15
ERROR - 2021-04-24 14:22:12 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\gurpal\system\libraries\Email.php 1902
ERROR - 2021-04-24 14:24:14 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\gurpal\system\libraries\Email.php 1902
ERROR - 2021-04-24 15:36:32 --> 404 Page Not Found: Register/vendor
ERROR - 2021-04-24 15:36:32 --> 404 Page Not Found: Register/css
ERROR - 2021-04-24 15:36:32 --> 404 Page Not Found: Register/js
ERROR - 2021-04-24 15:36:32 --> 404 Page Not Found: Register/vendor
ERROR - 2021-04-24 15:36:32 --> 404 Page Not Found: Register/vendor
ERROR - 2021-04-24 15:36:32 --> 404 Page Not Found: Register/vendor
ERROR - 2021-04-24 15:36:33 --> 404 Page Not Found: Register/vendor
ERROR - 2021-04-24 15:36:33 --> 404 Page Not Found: Register/vendor
ERROR - 2021-04-24 15:36:33 --> 404 Page Not Found: Register/js
ERROR - 2021-04-24 16:07:17 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\xampp\htdocs\gurpal\application\controllers\Register.php 27
ERROR - 2021-04-24 16:07:35 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\gurpal\application\controllers\Register.php 38
ERROR - 2021-04-24 16:07:48 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\xampp\htdocs\gurpal\application\controllers\Register.php 37
ERROR - 2021-04-24 16:14:28 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\gurpal\system\libraries\Email.php 1902
ERROR - 2021-04-24 16:17:35 --> 404 Page Not Found: Register/index
ERROR - 2021-04-24 16:18:11 --> 404 Page Not Found: Authentication/forgot_password
