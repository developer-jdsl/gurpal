<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-15 09:43:25 --> 404 Page Not Found: Home/index
ERROR - 2021-04-15 09:43:26 --> 404 Page Not Found: Home/index
ERROR - 2021-04-15 09:43:26 --> 404 Page Not Found: Home/index
ERROR - 2021-04-15 10:13:16 --> Severity: error --> Exception: Call to undefined function redirect() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 11
ERROR - 2021-04-15 10:14:48 --> Severity: error --> Exception: Call to undefined function redirect() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 11
ERROR - 2021-04-15 10:14:49 --> Severity: error --> Exception: Call to undefined function redirect() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 11
ERROR - 2021-04-15 10:15:52 --> Severity: error --> Exception: Call to undefined function redirect() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 11
ERROR - 2021-04-15 10:15:54 --> Severity: error --> Exception: Call to undefined function redirect() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 11
ERROR - 2021-04-15 11:46:08 --> 404 Page Not Found: Authentication/index.html
ERROR - 2021-04-15 11:46:15 --> 404 Page Not Found: Authentication/index.html
ERROR - 2021-04-15 12:34:43 --> 404 Page Not Found: Authentication/index.html
ERROR - 2021-04-15 12:37:49 --> Severity: error --> Exception: Call to undefined function validation_errors() E:\xampp\htdocs\gurpal\application\views\admin\login.php 21
ERROR - 2021-04-15 12:38:37 --> 404 Page Not Found: Form/index
ERROR - 2021-04-15 12:48:47 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 27
ERROR - 2021-04-15 13:16:42 --> Severity: Notice --> Undefined property: Authentication::$authentication_model E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 45
ERROR - 2021-04-15 13:16:42 --> Severity: error --> Exception: Call to a member function login() on null E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 45
ERROR - 2021-04-15 13:17:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`pk_admin_id,ap`.`fk_admin_id`)
WHERE `a`.`admin_email` = 'support@welexcare.co' at line 3 - Invalid query: SELECT *
FROM `tbl_admin` as `a`
LEFT JOIN `tbl_admin_profile` as `ap` USING (`a`.`pk_admin_id,ap`.`fk_admin_id`)
WHERE `a`.`admin_email` = 'support@welexcare.com'
AND `a`.`admin_password` = 'KPbHki+PCR76UfLpJzd0HHo4VDEDOQHU5ZUOh904SmJz3GfOZGSNCQ20qmPduVDuTGSIb6Zta9wVlNajXaxNWA=='
ERROR - 2021-04-15 13:18:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`pk_admin_id,ap`.`fk_admin_id`)
WHERE `a`.`admin_email` = 'support@welexcare.co' at line 3 - Invalid query: SELECT `a`.*, `ap`.*
FROM `tbl_admin` as `a`
LEFT JOIN `tbl_admin_profile` as `ap` USING (`a`.`pk_admin_id,ap`.`fk_admin_id`)
WHERE `a`.`admin_email` = 'support@welexcare.com'
AND `a`.`admin_password` = 'Gn6w+KiDxZUqwMQo5im/h1qlnchR2TpllHpr1F87sNY9vflo6TvUkZekgT3QavKA1Nf/SFhMY730ULoejbo+mg=='
ERROR - 2021-04-15 13:18:55 --> Query error: Unknown column 'ap.fk_admin_id' in 'on clause' - Invalid query: SELECT `a`.*, `ap`.*
FROM `tbl_admin` as `a`
LEFT JOIN `tbl_admin_profile` as `ap` ON `a`.`pk_admin_id`=`ap`.`fk_admin_id`
WHERE `a`.`admin_email` = 'support@welexcare.com'
AND `a`.`admin_password` = '5KodZcWoh0280pCwaB6vEyC7dbOS4tQ2oAcEX+YUXF60Xkik7k52xkdUahZg9Ep9TaN+uhBJU6TtY3yO9eOu+g=='
ERROR - 2021-04-15 13:19:47 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 16
ERROR - 2021-04-15 13:37:24 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) E:\xampp\htdocs\gurpal\application\views\admin\login.php 21
ERROR - 2021-04-15 13:37:26 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) E:\xampp\htdocs\gurpal\application\views\admin\login.php 21
ERROR - 2021-04-15 13:39:45 --> Severity: Notice --> Undefined variable: user_type E:\xampp\htdocs\gurpal\application\controllers\Authentication.php 47
ERROR - 2021-04-15 13:41:40 --> 404 Page Not Found: Admin/login
ERROR - 2021-04-15 13:41:47 --> 404 Page Not Found: Admin/login
ERROR - 2021-04-15 13:42:26 --> 404 Page Not Found: Authentication/login
ERROR - 2021-04-15 13:42:29 --> 404 Page Not Found: Authentication/login
ERROR - 2021-04-15 13:44:25 --> Severity: Notice --> Undefined property: CI_Loader::$encrypt E:\xampp\htdocs\gurpal\application\views\home.php 6
ERROR - 2021-04-15 13:44:25 --> Severity: error --> Exception: Call to a member function encode() on null E:\xampp\htdocs\gurpal\application\views\home.php 6
ERROR - 2021-04-15 14:26:46 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 16
ERROR - 2021-04-15 14:27:06 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 16
ERROR - 2021-04-15 14:31:10 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 16
ERROR - 2021-04-15 14:31:22 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 16
ERROR - 2021-04-15 14:31:36 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 16
ERROR - 2021-04-15 14:32:41 --> Severity: error --> Exception: syntax error, unexpected 'return' (T_RETURN) E:\xampp\htdocs\gurpal\application\models\Authentication_model.php 18
ERROR - 2021-04-15 14:38:32 --> 404 Page Not Found: Img/undraw_rocket.svg
ERROR - 2021-04-15 14:38:32 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-15 14:38:32 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-15 14:38:32 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-15 14:38:32 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-15 14:38:32 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-15 14:41:12 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-15 14:41:12 --> 404 Page Not Found: Img/undraw_rocket.svg
ERROR - 2021-04-15 14:41:12 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-15 14:41:12 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-15 14:41:12 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-15 14:41:12 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-15 14:41:51 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-15 14:41:51 --> 404 Page Not Found: Img/undraw_rocket.svg
ERROR - 2021-04-15 14:41:52 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-15 14:41:52 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-15 14:41:52 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-15 14:41:52 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-15 14:45:11 --> 404 Page Not Found: Img/undraw_rocket.svg
ERROR - 2021-04-15 14:45:11 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-15 14:45:11 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-15 14:45:11 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-15 14:45:11 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-15 14:45:11 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-15 15:21:49 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-15 15:21:49 --> 404 Page Not Found: Img/undraw_rocket.svg
ERROR - 2021-04-15 15:21:49 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-15 15:21:49 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-15 15:21:49 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-15 15:21:49 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-15 15:22:32 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-15 15:22:32 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-15 15:22:32 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-15 15:22:32 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-15 15:22:32 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-15 15:26:30 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-15 15:26:30 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-15 15:26:30 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-15 15:26:30 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-15 15:26:30 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-15 15:26:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 15:26:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 15:26:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 15:26:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 15:39:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 15:39:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 15:39:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 15:39:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 16:02:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 16:02:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 16:02:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-15 16:02:50 --> 404 Page Not Found: Admin/img
