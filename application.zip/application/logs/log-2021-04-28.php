<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-28 08:42:39 --> Severity: Notice --> Undefined index: fk_service_id E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 859
ERROR - 2021-04-28 12:21:23 --> Severity: Notice --> Undefined property: Home::$view E:\xampp\htdocs\gurpal\application\controllers\Home.php 21
ERROR - 2021-04-28 12:21:23 --> Severity: error --> Exception: Call to a member function load() on null E:\xampp\htdocs\gurpal\application\controllers\Home.php 21
ERROR - 2021-04-28 14:19:54 --> Severity: Notice --> Undefined property: Home::$admin_model E:\xampp\htdocs\gurpal\application\controllers\Home.php 37
ERROR - 2021-04-28 14:19:54 --> Severity: error --> Exception: Call to a member function get_service_cats() on null E:\xampp\htdocs\gurpal\application\controllers\Home.php 37
ERROR - 2021-04-28 14:32:56 --> Severity: Notice --> Undefined variable: categories E:\xampp\htdocs\gurpal\application\views\public\templates\sidebar.php 7
ERROR - 2021-04-28 14:32:56 --> Severity: Notice --> Undefined variable: categories E:\xampp\htdocs\gurpal\application\views\public\templates\sidebar.php 8
ERROR - 2021-04-28 14:32:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\public\templates\sidebar.php 8
ERROR - 2021-04-28 14:55:47 --> The upload path does not appear to be valid.
ERROR - 2021-04-28 14:55:47 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2685
ERROR - 2021-04-28 14:56:13 --> The upload path does not appear to be valid.
ERROR - 2021-04-28 14:56:13 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2685
ERROR - 2021-04-28 15:06:53 --> Severity: Notice --> Undefined index: banner_name E:\xampp\htdocs\gurpal\application\views\public\home.php 51
ERROR - 2021-04-28 15:06:53 --> Severity: Notice --> Undefined index: banner_name E:\xampp\htdocs\gurpal\application\views\public\home.php 51
ERROR - 2021-04-28 15:06:53 --> Severity: Notice --> Undefined index: banner_name E:\xampp\htdocs\gurpal\application\views\public\home.php 51
ERROR - 2021-04-28 15:06:53 --> Severity: Notice --> Undefined index: banner_name E:\xampp\htdocs\gurpal\application\views\public\home.php 51
ERROR - 2021-04-28 15:16:57 --> 404 Page Not Found: Uploads/brands
ERROR - 2021-04-28 15:16:57 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:16:57 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:16:57 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:16:57 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:16:57 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:16:57 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:17:55 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:17:55 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:17:55 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:17:56 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:17:56 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:17:56 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:20:16 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:20:16 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:20:16 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:20:16 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:20:16 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:20:16 --> 404 Page Not Found: Home/assets
ERROR - 2021-04-28 15:30:15 --> Query error: Unknown column 'a.admin_name' in 'field list' - Invalid query: SELECT `s`.*, `b`.`category_name`, `a`.`admin_name`, `p`.`discount_price`
FROM `tbl_services` as `s`
INNER JOIN `tbl_service_pricing` as `p` ON `s`.`pk_service_id`=`p`.`fk_service_id`
LEFT JOIN `tbl_business_category` as `b` ON `s`.`service_category`=`b`.`pk_category_id`
WHERE `s`.`active` = 1
AND `s`.`is_deleted` = 0
ERROR - 2021-04-28 15:30:41 --> Severity: Notice --> Undefined index: service_image E:\xampp\htdocs\gurpal\application\views\public\home.php 98
ERROR - 2021-04-28 15:30:41 --> Severity: Notice --> Undefined index: service_image E:\xampp\htdocs\gurpal\application\views\public\home.php 98
ERROR - 2021-04-28 15:30:41 --> Severity: Notice --> Undefined index: service_image E:\xampp\htdocs\gurpal\application\views\public\home.php 98
ERROR - 2021-04-28 15:43:08 --> Severity: error --> Exception: Call to undefined function word_limiter() E:\xampp\htdocs\gurpal\application\views\public\home.php 120
ERROR - 2021-04-28 15:43:38 --> Severity: error --> Exception: Call to undefined function word_limiter() E:\xampp\htdocs\gurpal\application\views\public\home.php 120
ERROR - 2021-04-28 15:43:51 --> Severity: error --> Exception: Call to undefined function word_limiter() E:\xampp\htdocs\gurpal\application\views\public\home.php 120
ERROR - 2021-04-28 15:44:00 --> Severity: error --> Exception: Call to undefined function word_limiter() E:\xampp\htdocs\gurpal\application\views\public\home.php 120
ERROR - 2021-04-28 15:44:16 --> Severity: error --> Exception: Call to undefined function word_limiter() E:\xampp\htdocs\gurpal\application\views\public\home.php 120
ERROR - 2021-04-28 15:48:39 --> Severity: Notice --> Undefined index: original_price E:\xampp\htdocs\gurpal\application\views\public\home.php 125
ERROR - 2021-04-28 15:48:39 --> Severity: Notice --> Undefined index: original_price E:\xampp\htdocs\gurpal\application\views\public\home.php 125
ERROR - 2021-04-28 16:02:12 --> Severity: Notice --> Undefined index: original_price E:\xampp\htdocs\gurpal\application\views\public\home.php 126
ERROR - 2021-04-28 16:02:12 --> Severity: Notice --> Undefined index: original_price E:\xampp\htdocs\gurpal\application\views\public\home.php 126
ERROR - 2021-04-28 16:09:32 --> Severity: Notice --> Undefined index: product_description E:\xampp\htdocs\gurpal\application\views\public\home.php 187
ERROR - 2021-04-28 16:09:32 --> Severity: Notice --> Undefined index: product_description E:\xampp\htdocs\gurpal\application\views\public\home.php 187
ERROR - 2021-04-28 16:09:32 --> Severity: Notice --> Undefined index: product_description E:\xampp\htdocs\gurpal\application\views\public\home.php 187
ERROR - 2021-04-28 16:09:54 --> Severity: Notice --> Undefined index: product_description E:\xampp\htdocs\gurpal\application\views\public\home.php 187
ERROR - 2021-04-28 16:09:54 --> Severity: Notice --> Undefined index: product_description E:\xampp\htdocs\gurpal\application\views\public\home.php 187
ERROR - 2021-04-28 16:09:54 --> Severity: Notice --> Undefined index: product_description E:\xampp\htdocs\gurpal\application\views\public\home.php 187
ERROR - 2021-04-28 16:12:27 --> Severity: Notice --> Undefined index: fk_product_id E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 847
