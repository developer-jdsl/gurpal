<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 06:21:51 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-19 06:21:52 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-19 06:21:52 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-19 06:21:52 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-19 06:21:52 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-19 06:21:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:21:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:21:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:21:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:25:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 74
ERROR - 2021-04-19 06:25:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:25:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:25:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:25:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 80
ERROR - 2021-04-19 06:46:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 80
ERROR - 2021-04-19 06:46:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:46:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:47:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:47:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:47:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:47:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:47:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 80
ERROR - 2021-04-19 06:47:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:47:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:47:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 06:47:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:53:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:53:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:53:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:53:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:53:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 76
ERROR - 2021-04-19 07:53:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:53:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:53:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:53:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:03 --> Query error: Unknown column 'fk_products_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_product_pricing`
WHERE `fk_products_id` = '1'
ERROR - 2021-04-19 07:54:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 80
ERROR - 2021-04-19 07:54:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:54:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:55:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:55:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:55:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:55:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 80
ERROR - 2021-04-19 07:58:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:58:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:58:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 07:58:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:01:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:01:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:01:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:01:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:01:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 80
ERROR - 2021-04-19 08:01:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:01:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:01:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:01:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:04:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:04:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:04:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:04:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 80
ERROR - 2021-04-19 08:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:05:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:05:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:05:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:05:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 80
ERROR - 2021-04-19 08:05:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:05:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:05:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:05:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 80
ERROR - 2021-04-19 08:06:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 08:06:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:06:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:07:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:07:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:07:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:07:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 08:07:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:07:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:07:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 08:07:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 11:33:34 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-19 11:33:34 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-19 11:33:34 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-19 11:33:34 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-19 11:33:34 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-19 11:33:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 11:33:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 11:33:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 11:33:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 11:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 11:33:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 11:33:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 11:33:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 11:33:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 12:48:11 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 258
ERROR - 2021-04-19 12:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 258
ERROR - 2021-04-19 12:48:11 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 265
ERROR - 2021-04-19 12:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 265
ERROR - 2021-04-19 12:48:11 --> Severity: Notice --> Undefined index: original_price E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 270
ERROR - 2021-04-19 12:48:11 --> Severity: Notice --> Undefined index: discount_price E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 271
ERROR - 2021-04-19 12:48:11 --> Severity: Notice --> Undefined index: pk_pricing_id E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 272
ERROR - 2021-04-19 12:48:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 12:48:38 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 258
ERROR - 2021-04-19 12:48:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 258
ERROR - 2021-04-19 12:48:38 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 265
ERROR - 2021-04-19 12:48:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 265
ERROR - 2021-04-19 12:48:38 --> Severity: Notice --> Undefined index: pk_pricing_id E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 272
ERROR - 2021-04-19 12:48:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:48:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:49:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:49:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:49:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:49:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 12:49:02 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 258
ERROR - 2021-04-19 12:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 258
ERROR - 2021-04-19 12:49:02 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 265
ERROR - 2021-04-19 12:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 265
ERROR - 2021-04-19 12:49:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:49:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:49:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:49:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:33 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 12:50:33 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:50:33 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:50:33 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:50:33 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:50:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 12:50:51 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:50:51 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:50:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:50:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:56:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:56:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:56:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:56:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 12:56:22 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:56:22 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:56:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:56:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:56:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:56:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:58:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:58:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:58:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:58:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 12:58:37 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:58:37 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:58:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:58:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:58:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:58:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 12:59:19 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:59:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:59:19 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:59:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:59:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 12:59:48 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:59:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 12:59:48 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:59:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 12:59:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 12:59:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:00:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:00:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:00:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:00:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:00:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:00:05 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:00:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:00:05 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:00:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:00:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:00:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:00:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:00:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:01:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:01:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:01:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:01:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:01:56 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:01:56 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:01:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:01:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:01:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:01:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:02:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:02:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:02:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:02:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:02:19 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:02:19 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:02:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:02:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:02:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:02:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:03:27 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:03:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:03:27 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:03:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:03:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:03:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:04:01 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:04:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:04:01 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:04:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:04:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:17 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:04:17 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:04:17 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:04:17 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:04:17 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:04:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:04:42 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:04:42 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:04:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:09:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:09:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:09:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:09:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:09:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:09:14 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:09:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:09:14 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:09:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:09:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:09:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:09:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:09:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:10:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:10:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:10:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:10:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:10:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:10:11 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:10:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 261
ERROR - 2021-04-19 13:10:11 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:10:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 268
ERROR - 2021-04-19 13:10:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:10:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:10:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:10:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:16:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:16:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:16:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:16:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:16:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:16:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:16:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:16:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:16:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:23:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:23:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:23:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:23:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:23:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:23:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:23:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:23:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:24:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:24:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:24:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:24:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:24:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:24:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:24:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:24:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:24:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:26:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:26:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:26:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:26:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:26:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:26:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:26:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:26:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:26:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:28:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:28:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:28:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:28:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:28:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:28:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:28:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:28:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:28:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:35:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:35:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:35:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:35:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:35:45 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:35:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:35:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:35:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:35:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:50:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:50:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:50:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:51:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:51:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:51:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:51:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:51:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:51:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:51:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:51:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:54:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:54:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:54:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:54:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:54:03 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 13:54:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:54:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:54:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 13:54:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:12:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:12:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:12:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:12:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:12:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:12:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:12:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:12:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:12:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:45:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:45:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:45:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:45:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:45:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:45:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:45:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:45:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:45:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:46:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:46:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:46:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:46:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:46:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:46:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:46:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:46:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:46:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:46:57 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1335
ERROR - 2021-04-19 14:48:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:48:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:48:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:48:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:48:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:48:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:48:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:48:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:49:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:49:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:49:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:49:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:49:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:49:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:49:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:49:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:51:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:51:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:51:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:51:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:52:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:52:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:52:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:52:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:52:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:55:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:55:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:55:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:55:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:55:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:55:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:55:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:55:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:57:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:57:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:57:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:57:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:57:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:57:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:57:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:57:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:57:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:03 --> Severity: error --> Exception: Call to undefined method Admin_model::get_where() E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 619
ERROR - 2021-04-19 14:58:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:58:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:58:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:04 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:59:04 --> Severity: Notice --> Undefined index: pk_pricing_id E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 190
ERROR - 2021-04-19 14:59:04 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 14:59:04 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 14:59:04 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 14:59:04 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 14:59:04 --> Severity: Notice --> Undefined index: pk_pricing_id E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 221
ERROR - 2021-04-19 14:59:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:05 --> 404 Page Not Found: Uploads/products
ERROR - 2021-04-19 14:59:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 14:59:54 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 14:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 14:59:54 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 14:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 14:59:54 --> Severity: Notice --> Undefined index: pk_pricing_id E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 221
ERROR - 2021-04-19 14:59:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 14:59:54 --> 404 Page Not Found: Uploads/products
ERROR - 2021-04-19 15:00:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:00:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:00:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:00:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:00:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 15:00:25 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 15:00:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 15:00:25 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 15:00:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 15:00:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:00:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:00:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:00:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:00:26 --> 404 Page Not Found: Uploads/products
ERROR - 2021-04-19 15:01:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:01:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:01:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:01:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:01:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 15:01:29 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 15:01:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 15:01:29 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 15:01:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 15:01:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:01:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:01:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:01:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:01:30 --> 404 Page Not Found: Uploads/products
ERROR - 2021-04-19 15:02:07 --> 404 Page Not Found: Uploads/products
ERROR - 2021-04-19 15:02:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:02:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:02:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:02:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:02:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 15:02:34 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 15:02:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 15:02:34 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 15:02:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 15:02:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:02:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:02:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:02:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:27:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:27:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:27:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:27:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 81
ERROR - 2021-04-19 15:27:51 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 15:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 197
ERROR - 2021-04-19 15:27:51 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 15:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 205
ERROR - 2021-04-19 15:27:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:27:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:27:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:27:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:30:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:30:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:30:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:30:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:30:28 --> Severity: Notice --> Undefined variable: colors E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 199
ERROR - 2021-04-19 15:30:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 199
ERROR - 2021-04-19 15:30:28 --> Severity: Notice --> Undefined variable: sizes E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 207
ERROR - 2021-04-19 15:30:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 207
ERROR - 2021-04-19 15:30:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:30:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:30:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:30:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:36:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:36:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:36:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:36:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:36:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:36:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:36:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:36:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:38:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:38:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:38:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:38:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:38:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:38:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:38:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 15:38:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:03:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:03:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:03:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:03:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:05:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:11:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:11:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:11:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:11:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:11:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:11:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:11:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:11:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:12:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:14:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:14:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:14:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:14:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:15:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:15:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:15:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:15:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:15:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:15:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:15:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:15:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:16:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:16:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:16:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:16:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:17:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:17:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:17:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:17:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:17:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:17:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:17:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:17:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:18:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:18:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:18:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:18:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:18:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:18:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:18:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:18:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:18:28 --> Severity: Notice --> Undefined index: product_image_1 E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1479
ERROR - 2021-04-19 16:19:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:19:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:19:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:19:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:19:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:19:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:19:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:19:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:19:36 --> Severity: Notice --> Undefined index: product_image_1 E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1481
ERROR - 2021-04-19 16:20:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:20:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:20:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:20:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:20:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:20:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:20:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:20:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:34 --> The upload path does not appear to be valid.
ERROR - 2021-04-19 16:21:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:21:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:17 --> 404 Page Not Found: Upload/Blog_Image-Honey1.jpg
ERROR - 2021-04-19 16:23:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:23:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:24:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:24:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:24:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:24:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:24:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:24:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:24:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:24:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:25:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:25:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:25:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:25:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:25:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:25:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:25:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:25:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:26:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:26:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:26:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:26:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:26:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:26:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:26:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:26:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:29:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:30:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:30:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:30:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:30:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:30:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:30:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:30:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:30:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:38:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:40:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:41:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:41:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:41:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:41:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:46:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:47:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:47:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:47:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:47:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:48:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:48:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:48:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:48:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:48:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:48:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:48:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 16:48:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-19 17:00:20 --> 404 Page Not Found: Admin/img
