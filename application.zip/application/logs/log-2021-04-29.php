<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-29 12:30:17 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-04-29 15:21:59 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:21:59 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:22:01 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:27:07 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:27:07 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:27:51 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:27:51 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:53:21 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:53:21 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:55:10 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:55:10 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 42
ERROR - 2021-04-29 15:55:46 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:55:46 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 15:59:05 --> 404 Page Not Found: 
ERROR - 2021-04-29 15:59:06 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> Severity: Warning --> Illegal string offset 'product_image' E:\xampp\htdocs\gurpal\application\views\public\single_product.php 41
ERROR - 2021-04-29 16:00:02 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:00:02 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:00:39 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:00:39 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:01:06 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:01:07 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:08:09 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:08:09 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:08:34 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:08:34 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:41:08 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:41:09 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:42:00 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:42:00 --> 404 Page Not Found: 
ERROR - 2021-04-29 16:42:22 --> 404 Page Not Found: 
ERROR - 2021-04-29 17:00:51 --> Severity: Notice --> Undefined index: pk_size_id E:\xampp\htdocs\gurpal\application\views\public\single_product.php 78
ERROR - 2021-04-29 17:00:51 --> Severity: Notice --> Undefined index: pk_color_id E:\xampp\htdocs\gurpal\application\views\public\single_product.php 84
ERROR - 2021-04-29 17:00:51 --> Severity: Notice --> Undefined index: pk_size_id E:\xampp\htdocs\gurpal\application\views\public\single_product.php 84
