<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-20 06:28:48 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-20 06:28:48 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-20 06:28:48 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-20 06:28:48 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-20 06:28:48 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-20 06:28:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:28:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:28:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:28:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:37:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:37:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:37:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:37:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:37:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:37:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:37:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:37:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:38:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 06:40:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:03:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:20 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-20 08:09:20 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-20 08:09:20 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-20 08:09:20 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-20 08:09:20 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-20 08:09:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:09:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:11:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:14:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:14:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:14:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:14:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:14:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:14:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:14:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:14:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:15:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:15:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:15:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:15:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:29:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:29:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:29:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:29:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:29:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:29:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:29:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:29:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:30:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:30:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:30:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:30:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:30:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:30:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:30:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:30:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:31:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:31:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:31:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:31:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:31:44 --> Severity: error --> Exception: Call to undefined method Admin_model::get_colors() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1611
ERROR - 2021-04-20 08:32:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:08 --> Severity: error --> Exception: Call to undefined method Admin_model::get_sizes() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1612
ERROR - 2021-04-20 08:32:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:32:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:35:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:35:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:35:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:35:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:35:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:35:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:35:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:35:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:36:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:36:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:36:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:36:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:36:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:36:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:36:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:36:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:37:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:37:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:37:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:37:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:37:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:37:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:37:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:37:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 08:38:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 09:28:38 --> Severity: error --> Exception: syntax error, unexpected '}' E:\xampp\htdocs\gurpal\application\models\Home_model.php 70
ERROR - 2021-04-20 09:28:59 --> Severity: Notice --> Undefined variable: records E:\xampp\htdocs\gurpal\application\models\Home_model.php 78
ERROR - 2021-04-20 09:28:59 --> Severity: error --> Exception: Call to a member function num_rows() on null E:\xampp\htdocs\gurpal\application\models\Home_model.php 78
ERROR - 2021-04-20 10:28:37 --> Severity: Compile Error --> Cannot redeclare Admin::edit_brand() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2101
ERROR - 2021-04-20 10:30:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:30:39 --> Severity: Notice --> Undefined index: city_name E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 234
ERROR - 2021-04-20 10:31:09 --> Severity: Error --> Maximum execution time of 30 seconds exceeded E:\xampp\htdocs\gurpal\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2021-04-20 10:32:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:32:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:32:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:32:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:32:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:32:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:32:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:32:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:33:03 --> Severity: Error --> Maximum execution time of 30 seconds exceeded E:\xampp\htdocs\gurpal\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2021-04-20 10:38:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 10:38:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:08:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:08:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:08:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:08:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:08:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:08:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:08:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:08:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:08:22 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1790
ERROR - 2021-04-20 11:08:23 --> Query error: Column 'product_image' cannot be null - Invalid query: INSERT INTO `tbl_product_pricing` (`discount_price`, `fk_color_id`, `fk_product_id`, `fk_size_id`, `original_price`, `product_image`, `quantity`) VALUES ('','0','1','0','',NULL,'')
ERROR - 2021-04-20 11:11:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:11:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:11:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:11:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:11:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:11:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:11:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:11:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:11:27 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1792
ERROR - 2021-04-20 11:11:27 --> Query error: Column 'product_image' cannot be null - Invalid query: INSERT INTO `tbl_product_pricing` (`discount_price`, `fk_color_id`, `fk_product_id`, `fk_size_id`, `original_price`, `product_image`, `quantity`) VALUES ('','0','1','0','',NULL,'')
ERROR - 2021-04-20 11:13:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:13:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:13:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:13:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:13:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:13:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:13:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:13:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:13:43 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1793
ERROR - 2021-04-20 11:13:43 --> Query error: Column 'product_image' cannot be null - Invalid query: INSERT INTO `tbl_product_pricing` (`discount_price`, `fk_color_id`, `fk_product_id`, `fk_size_id`, `original_price`, `product_image`, `quantity`) VALUES ('','0','1','0','',NULL,'')
ERROR - 2021-04-20 11:15:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:15:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:15:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:15:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:15:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:15:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:15:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:15:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:15:41 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1793
ERROR - 2021-04-20 11:15:41 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-20 11:15:41 --> Severity: Warning --> array_diff(): Argument #2 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-20 11:15:41 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-20 11:15:41 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-20 11:15:41 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-20 11:15:41 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-20 11:15:41 --> Query error: Column count doesn't match value count at row 2 - Invalid query: INSERT INTO `tbl_product_pricing` (`discount_price`, `fk_color_id`, `fk_product_id`, `fk_size_id`, `original_price`, `product_image`, `quantity`) VALUES ('','0','1','0','',NULL,''), ()
ERROR - 2021-04-20 11:15:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\gurpal\system\core\Exceptions.php:271) E:\xampp\htdocs\gurpal\system\core\Common.php 570
ERROR - 2021-04-20 11:16:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:16:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:16:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:16:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:16:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:16:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:16:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:16:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:16:33 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1793
ERROR - 2021-04-20 11:17:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:11 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1793
ERROR - 2021-04-20 11:17:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:17:45 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1793
ERROR - 2021-04-20 11:18:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:18:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:19:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:19:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:19:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:19:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:19:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 77
ERROR - 2021-04-20 11:19:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:19:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:19:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:19:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 77
ERROR - 2021-04-20 11:20:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:20:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:20:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:20:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:22:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 77
ERROR - 2021-04-20 11:22:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:22:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:22:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:22:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:23:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:23:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:23:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:23:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 77
ERROR - 2021-04-20 11:25:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:25:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:25:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:25:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:25:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:25:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:25:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:25:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:05 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 746
ERROR - 2021-04-20 11:26:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:15 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 746
ERROR - 2021-04-20 11:26:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 77
ERROR - 2021-04-20 11:26:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 198
ERROR - 2021-04-20 11:26:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:26:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:27:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:24 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 746
ERROR - 2021-04-20 11:28:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:28:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:12 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 746
ERROR - 2021-04-20 11:48:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:33 --> Query error: Unknown column 'fk_products_id' in 'where clause' - Invalid query: DELETE FROM `tbl_product_pricing`
WHERE `fk_products_id` = '2'
ERROR - 2021-04-20 11:48:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:48:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:49:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:50:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:50:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:50:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:50:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:50:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:50:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:50:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:50:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:51:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:51:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:51:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:51:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:51:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:51:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:51:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:51:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:52:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:52:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:52:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:52:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:52:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:52:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:52:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:52:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:53:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:53:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:53:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 11:53:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:50:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:50:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:50:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:50:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:51:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:51:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:51:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:51:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:51:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:51:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:51:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:51:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:52:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:52:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:52:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 12:52:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 13:46:07 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2104
ERROR - 2021-04-20 13:46:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 13:46:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 13:46:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 13:46:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 13:46:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 13:46:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 13:46:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 13:46:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:07:55 --> Severity: Notice --> Undefined variable: admin E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 88
ERROR - 2021-04-20 14:07:55 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 111
ERROR - 2021-04-20 14:07:55 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 111
ERROR - 2021-04-20 14:07:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:07:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:07:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:07:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:08:18 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 111
ERROR - 2021-04-20 14:08:18 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 111
ERROR - 2021-04-20 14:08:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:08:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:08:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:08:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:09:14 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 111
ERROR - 2021-04-20 14:09:14 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 111
ERROR - 2021-04-20 14:09:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:09:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:09:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:09:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:09:59 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:09:59 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:09:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:09:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:09:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:09:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:11:10 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:11:10 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:11:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:11:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:11:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:11:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:11:48 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:11:48 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:11:48 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:11:48 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:11:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:11:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:11:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:11:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:12:53 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:12:53 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:12:53 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:12:53 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:12:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:12:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:12:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:12:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:13:42 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:13:42 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:13:42 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:13:42 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:13:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:13:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:13:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:13:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:14:10 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:14:10 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:14:10 --> Severity: Warning --> Illegal string offset 'pk_admin_id' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:14:10 --> Severity: Warning --> Illegal string offset 'admin_name' E:\xampp\htdocs\gurpal\application\views\admin\ads\add_ad.php 114
ERROR - 2021-04-20 14:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:14:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:14:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:14:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:14:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:17:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:18:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:18:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:18:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:18:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:18:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:18:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:18:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:18:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:19:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:52:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:52:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:52:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:52:59 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:53:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:53:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:53:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:53:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:54:44 --> Severity: error --> Exception: Call to undefined function get_mime_by_extension() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2134
ERROR - 2021-04-20 14:55:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:55:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:55:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:55:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:55:36 --> Severity: error --> Exception: Call to undefined function get_mime_by_extension() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 2134
ERROR - 2021-04-20 14:56:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:56:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:56:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:56:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 14:56:30 --> Severity: Notice --> Undefined index: brand_name E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 934
ERROR - 2021-04-20 14:56:30 --> Severity: Notice --> Undefined index: brand_image E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 934
ERROR - 2021-04-20 14:56:30 --> Severity: Notice --> Undefined index: created_by E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 934
ERROR - 2021-04-20 14:56:30 --> Query error: Column 'brand_name' cannot be null - Invalid query: INSERT INTO `tbl_brands` (`brand_name`, `brand_image`, `active`, `created_by`) VALUES (NULL, NULL, '1', NULL)
ERROR - 2021-04-20 15:00:18 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 934
ERROR - 2021-04-20 15:00:20 --> Severity: error --> Exception: syntax error, unexpected ')' E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 934
ERROR - 2021-04-20 15:00:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:00:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:00:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:00:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:00:54 --> Severity: Notice --> Undefined variable: slug E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 936
ERROR - 2021-04-20 15:00:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:00:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:00:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:00:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:01:06 --> Severity: Notice --> Undefined index: brand_name E:\xampp\htdocs\gurpal\application\views\admin\ads\ads.php 54
ERROR - 2021-04-20 15:01:06 --> Severity: Notice --> Undefined index: pk_brand_id E:\xampp\htdocs\gurpal\application\views\admin\ads\ads.php 59
ERROR - 2021-04-20 15:01:06 --> Severity: Notice --> Undefined index: pk_brand_id E:\xampp\htdocs\gurpal\application\views\admin\ads\ads.php 65
ERROR - 2021-04-20 15:01:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:01:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:01:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:01:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:03:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:03:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:03:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:03:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:03:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:03:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:03:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:03:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:22 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 100
ERROR - 2021-04-20 15:04:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:38 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 100
ERROR - 2021-04-20 15:04:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:04:53 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 100
ERROR - 2021-04-20 15:05:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:13 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 113
ERROR - 2021-04-20 15:05:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:24 --> Severity: Notice --> Undefined variable: results E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 138
ERROR - 2021-04-20 15:05:24 --> Severity: Notice --> Undefined variable: results E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 139
ERROR - 2021-04-20 15:05:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:05:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:06:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:06:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:06:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:06:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:06:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:06:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:06:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:06:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:07:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:08:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:08:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:08:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:08:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:08:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:08:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:08:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:08:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 33
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 37
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 41
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 57
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 62
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 69
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 70
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 71
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 72
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 73
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 82
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 83
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 84
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 85
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 86
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 87
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 88
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 94
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 107
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 126
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 138
ERROR - 2021-04-20 15:11:45 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 139
ERROR - 2021-04-20 15:11:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:11:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:11:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:11:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 33
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 37
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 41
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 57
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 62
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 69
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 70
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 71
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 72
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 73
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 82
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 83
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 84
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 85
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 86
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 87
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 88
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 94
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 107
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 126
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 138
ERROR - 2021-04-20 15:11:49 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 139
ERROR - 2021-04-20 15:11:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:11:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:11:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:11:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:12:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:12:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:12:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:12:58 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:03 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:11 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:14 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 33
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 37
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 41
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 57
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 62
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 69
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 70
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 71
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 72
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 73
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 82
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 83
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 84
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 85
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 86
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 87
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 88
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 94
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 107
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 126
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 138
ERROR - 2021-04-20 15:13:55 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 139
ERROR - 2021-04-20 15:13:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:13:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:14:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:14:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:14:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:14:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:14:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:14:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:14:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:14:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 33
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 37
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 41
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 57
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 62
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 69
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 70
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 71
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 72
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 73
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 82
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 83
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 84
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 85
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 86
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 87
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 88
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 94
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 107
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 126
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 138
ERROR - 2021-04-20 15:15:15 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 139
ERROR - 2021-04-20 15:15:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:41 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:15:44 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 33
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 37
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 41
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 57
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 62
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 69
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 70
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 71
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 72
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 73
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 82
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 83
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 84
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 85
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 86
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 87
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 88
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 94
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 107
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 126
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 138
ERROR - 2021-04-20 15:16:33 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 139
ERROR - 2021-04-20 15:16:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:33 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 33
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 37
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 41
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 57
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 62
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 69
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 70
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 71
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 72
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 73
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 82
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 83
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 84
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 85
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 86
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 87
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 88
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 94
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 107
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 126
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 138
ERROR - 2021-04-20 15:16:35 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 139
ERROR - 2021-04-20 15:16:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:45 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:16:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:17:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:17:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:17:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:17:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:17:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:17:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:17:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:17:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 33
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 37
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 41
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 57
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 62
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 69
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 70
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 71
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 72
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 73
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 82
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 83
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 84
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 85
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 86
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 87
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 88
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 94
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 107
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 126
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 138
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 139
ERROR - 2021-04-20 15:21:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\gurpal\application\views\admin\ads\edit_ad.php 145
ERROR - 2021-04-20 15:21:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:21:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:21:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:21:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:01 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:10 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-20 15:22:10 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-20 15:22:10 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-20 15:22:10 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-20 15:22:11 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-20 15:22:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:22:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:23:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:18 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 15:25:25 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:09:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:09:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:09:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:09:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:09:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:09:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:09:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:09:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:13:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:13:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:13:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:13:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:13:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:13:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:13:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:13:57 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:14:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:16:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:16:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:16:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:16:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:17:34 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:18:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:18:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:18:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:18:19 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:19:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:19:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:19:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:19:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:20:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:20:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:20:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:20:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:20:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:20:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:20:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:20:51 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:21:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:21:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:21:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:21:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:21:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:21:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:21:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:21:21 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:24:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:24:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:24:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:24:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:24:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:24:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:24:38 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-20 16:24:38 --> 404 Page Not Found: Admin/img
