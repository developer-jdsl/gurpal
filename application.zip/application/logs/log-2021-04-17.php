<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-17 07:46:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\xampp\htdocs\gurpal\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-04-17 07:46:21 --> Unable to connect to the database
ERROR - 2021-04-17 07:46:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\xampp\htdocs\gurpal\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-04-17 07:46:23 --> Unable to connect to the database
ERROR - 2021-04-17 07:49:36 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-17 07:49:36 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-17 07:49:36 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-17 07:49:36 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-17 07:49:36 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-17 07:54:39 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-17 07:54:39 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-17 07:54:39 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-17 07:54:39 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-17 07:54:39 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-17 08:26:59 --> Severity: error --> Exception: syntax error, unexpected end of file E:\xampp\htdocs\gurpal\application\views\admin\templates\sidebar.php 59
ERROR - 2021-04-17 08:27:15 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-17 08:27:15 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-17 08:27:15 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-17 08:27:15 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-17 08:27:15 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-17 08:38:01 --> Severity: error --> Exception: Using $this when not in object context E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 20
ERROR - 2021-04-17 08:40:59 --> Severity: Compile Error --> Cannot re-assign $this E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 9
ERROR - 2021-04-17 08:41:37 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-17 08:41:37 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-17 08:41:37 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-17 08:41:37 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-17 08:41:37 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-17 08:43:13 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-17 08:43:13 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-17 08:43:13 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-17 08:43:13 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-17 08:43:13 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-17 08:43:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 08:43:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 08:43:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 08:43:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 11:58:36 --> 404 Page Not Found: Admin/products
ERROR - 2021-04-17 11:58:44 --> 404 Page Not Found: Admin/products
ERROR - 2021-04-17 12:02:47 --> Severity: Compile Error --> Cannot redeclare Admin_model::get_products() E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 351
ERROR - 2021-04-17 12:03:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:03:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:03:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:03:08 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:03:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:03:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:03:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:03:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:03:35 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-17 12:03:35 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-17 12:03:35 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-17 12:03:35 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-17 12:03:35 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-17 12:08:04 --> 404 Page Not Found: 
ERROR - 2021-04-17 12:17:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:17:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:17:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:17:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:17:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:17:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:17:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:17:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:17:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:17:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:18:25 --> Severity: error --> Exception: Using $this when not in object context E:\xampp\htdocs\gurpal\application\helpers\common_helper.php 42
ERROR - 2021-04-17 12:18:44 --> 404 Page Not Found: Img/undraw_profile_1.svg
ERROR - 2021-04-17 12:18:44 --> 404 Page Not Found: Img/undraw_profile_3.svg
ERROR - 2021-04-17 12:18:44 --> 404 Page Not Found: Img/undraw_profile_2.svg
ERROR - 2021-04-17 12:18:44 --> 404 Page Not Found: Img/undraw_profile.svg
ERROR - 2021-04-17 12:18:44 --> 404 Page Not Found: Img/undraw_posting_photo.svg
ERROR - 2021-04-17 12:18:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:18:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:18:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:18:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:18:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:18:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:18:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:18:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:27:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:27:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:27:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:27:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:30:51 --> 404 Page Not Found: Admin/colors
ERROR - 2021-04-17 12:31:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:31:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:31:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:31:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:31:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:31:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:31:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 12:31:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:35 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:52 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:41:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:07 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 13:42:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:03:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:03:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:03:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:03:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:05:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:05:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:05:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:05:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:06:02 --> Severity: Notice --> Undefined property: Admin::$column E:\xampp\htdocs\gurpal\system\core\Model.php 73
ERROR - 2021-04-17 14:06:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 406
ERROR - 2021-04-17 14:06:02 --> Severity: Notice --> Undefined index: length E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 431
ERROR - 2021-04-17 14:06:02 --> Severity: Notice --> Undefined index: length E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 432
ERROR - 2021-04-17 14:06:02 --> Severity: Notice --> Undefined index: start E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 432
ERROR - 2021-04-17 14:06:02 --> Severity: Notice --> Undefined index: start E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1027
ERROR - 2021-04-17 14:06:02 --> Severity: Notice --> Undefined index: draw E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1040
ERROR - 2021-04-17 14:06:02 --> Severity: Notice --> Undefined property: Admin::$column E:\xampp\htdocs\gurpal\system\core\Model.php 73
ERROR - 2021-04-17 14:06:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 406
ERROR - 2021-04-17 14:09:21 --> Severity: Notice --> Undefined index: search E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 408
ERROR - 2021-04-17 14:09:21 --> Severity: Notice --> Undefined index: search E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 408
ERROR - 2021-04-17 14:09:21 --> Severity: Notice --> Undefined index: length E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 431
ERROR - 2021-04-17 14:09:21 --> Severity: Notice --> Undefined index: length E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 432
ERROR - 2021-04-17 14:09:21 --> Severity: Notice --> Undefined index: start E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 432
ERROR - 2021-04-17 14:09:21 --> Severity: Notice --> Undefined index: start E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1027
ERROR - 2021-04-17 14:09:21 --> Severity: Notice --> Undefined index: draw E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1040
ERROR - 2021-04-17 14:09:21 --> Severity: Notice --> Undefined index: search E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 408
ERROR - 2021-04-17 14:09:21 --> Severity: Notice --> Undefined index: search E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 408
ERROR - 2021-04-17 14:09:44 --> Severity: Notice --> Undefined index: length E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 431
ERROR - 2021-04-17 14:09:44 --> Severity: Notice --> Undefined index: length E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 432
ERROR - 2021-04-17 14:09:44 --> Severity: Notice --> Undefined index: start E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 432
ERROR - 2021-04-17 14:09:44 --> Severity: Notice --> Undefined index: start E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1027
ERROR - 2021-04-17 14:09:44 --> Severity: Notice --> Undefined index: draw E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1040
ERROR - 2021-04-17 14:10:06 --> Severity: Notice --> Undefined index: length E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 431
ERROR - 2021-04-17 14:10:06 --> Severity: Notice --> Undefined index: start E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1027
ERROR - 2021-04-17 14:10:06 --> Severity: Notice --> Undefined index: draw E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1040
ERROR - 2021-04-17 14:10:15 --> Severity: Notice --> Undefined index: start E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1027
ERROR - 2021-04-17 14:10:15 --> Severity: Notice --> Undefined index: draw E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1040
ERROR - 2021-04-17 14:10:48 --> Severity: Notice --> Undefined index: draw E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1040
ERROR - 2021-04-17 14:11:20 --> Severity: Notice --> Undefined index: draw E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1040
ERROR - 2021-04-17 14:11:21 --> Severity: Notice --> Undefined index: draw E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1040
ERROR - 2021-04-17 14:12:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:12:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:12:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:12:43 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:15:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:15:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:15:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:15:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:17:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:17:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:17:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:17:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:25:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:25:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:25:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:25:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:28:12 --> Severity: Notice --> Undefined index: length E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 431
ERROR - 2021-04-17 14:28:12 --> Severity: Notice --> Undefined index: length E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 432
ERROR - 2021-04-17 14:28:12 --> Severity: Notice --> Undefined index: start E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 432
ERROR - 2021-04-17 14:29:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:29:04 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:29:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:29:05 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:31:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:31:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:31:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:31:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:38:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:38:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:38:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:38:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:48:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:48:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:48:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:48:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:48:33 --> Severity: error --> Exception: Call to undefined method Admin_model::get_admins() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1091
ERROR - 2021-04-17 14:53:48 --> Severity: Notice --> Undefined variable: results E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 476
ERROR - 2021-04-17 14:53:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:53:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:53:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:53:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:54:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:54:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:54:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:54:02 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:59:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:59:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:59:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 14:59:22 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 15:16:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 15:16:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 15:16:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 15:16:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 15:37:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 15:37:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 15:37:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 15:37:00 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:22:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:22:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:22:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:22:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:33:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:33:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:33:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:33:39 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:34:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:34:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:34:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:34:16 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:37:36 --> Severity: Notice --> Undefined index: gst_name E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 81
ERROR - 2021-04-17 16:37:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:37:36 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:37:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:37:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:37:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:37:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:37:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:37:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:38:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:38:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:38:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:38:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:42:11 --> Severity: error --> Exception: Call to undefined method Admin_model::get_product_cats() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1088
ERROR - 2021-04-17 16:45:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:45:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:45:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:45:37 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:47:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:47:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:47:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:47:32 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:49:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:49:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:49:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:49:31 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 137
ERROR - 2021-04-17 16:55:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:55:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:55:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:55:15 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:56:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 137
ERROR - 2021-04-17 16:56:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:56:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:56:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:56:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:57:16 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 76
ERROR - 2021-04-17 16:57:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:57:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:57:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 16:57:17 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:03:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 76
ERROR - 2021-04-17 17:03:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:03:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:03:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:03:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:13:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 76
ERROR - 2021-04-17 17:13:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:13:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:13:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:13:06 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:13:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 76
ERROR - 2021-04-17 17:13:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:13:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:13:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:13:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 76
ERROR - 2021-04-17 17:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:14:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:14:30 --> Query error: Column 'cross_sell' cannot be null - Invalid query: INSERT INTO `tbl_products` (`product_name`, `product_sku`, `product_description`, `product_brand`, `product_specifications`, `cross_sell`, `meta_title`, `meta_keyword`, `meta_description`, `is_cod`, `ordering`, `fk_gst_id`, `fk_admin_id`, `product_category`, `active`, `created_by`) VALUES ('111', 'qqq', '111', '1', '1111', NULL, '', NULL, '', '1', '', '1', '1', '1', '1', '1')
ERROR - 2021-04-17 17:15:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 76
ERROR - 2021-04-17 17:15:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:15:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:15:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:15:09 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:15:23 --> Query error: Column 'meta_keyword' cannot be null - Invalid query: INSERT INTO `tbl_products` (`product_name`, `product_sku`, `product_description`, `product_brand`, `product_specifications`, `meta_title`, `meta_keyword`, `meta_description`, `is_cod`, `ordering`, `fk_gst_id`, `fk_admin_id`, `product_category`, `active`, `created_by`) VALUES ('111', '111', '111', '1', '11', '', NULL, '', '1', '', '1', '1', '1', '1', '1')
ERROR - 2021-04-17 17:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\add_product.php 76
ERROR - 2021-04-17 17:16:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:16:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:16:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:16:12 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:16:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:16:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:16:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:16:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:16:25 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1033
ERROR - 2021-04-17 17:16:25 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1034
ERROR - 2021-04-17 17:16:25 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1035
ERROR - 2021-04-17 17:16:25 --> Severity: Notice --> Undefined index: pk_product_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1038
ERROR - 2021-04-17 17:16:25 --> Severity: Notice --> Undefined index: pk_product_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1041
ERROR - 2021-04-17 17:17:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:17:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:17:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:17:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:17:29 --> Severity: Notice --> Undefined index: product_name E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1033
ERROR - 2021-04-17 17:17:29 --> Severity: Notice --> Undefined index: quantity E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1034
ERROR - 2021-04-17 17:17:29 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1035
ERROR - 2021-04-17 17:17:29 --> Severity: Notice --> Undefined index: pk_product_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1038
ERROR - 2021-04-17 17:17:29 --> Severity: Notice --> Undefined index: pk_product_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1041
ERROR - 2021-04-17 17:18:34 --> Severity: error --> Exception: syntax error, unexpected 'Active' (T_STRING), expecting ']' E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1035
ERROR - 2021-04-17 17:18:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:18:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:18:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:18:48 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:18:48 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1033
ERROR - 2021-04-17 17:18:48 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1034
ERROR - 2021-04-17 17:18:48 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1035
ERROR - 2021-04-17 17:18:48 --> Severity: Notice --> Undefined index: pk_product_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1038
ERROR - 2021-04-17 17:18:48 --> Severity: Notice --> Undefined index: pk_product_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1041
ERROR - 2021-04-17 17:19:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:19:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:19:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:19:13 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:19:14 --> Severity: Notice --> Undefined index: product_name E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1033
ERROR - 2021-04-17 17:19:14 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1034
ERROR - 2021-04-17 17:19:14 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1035
ERROR - 2021-04-17 17:19:14 --> Severity: Notice --> Undefined index: pk_product_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1038
ERROR - 2021-04-17 17:19:14 --> Severity: Notice --> Undefined index: pk_product_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1041
ERROR - 2021-04-17 17:20:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:20:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:20:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:20:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:20:25 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1035
ERROR - 2021-04-17 17:20:25 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1036
ERROR - 2021-04-17 17:20:25 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1037
ERROR - 2021-04-17 17:20:25 --> Severity: Notice --> Undefined index: pk_product_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1040
ERROR - 2021-04-17 17:20:25 --> Severity: Notice --> Undefined index: pk_product_id E:\xampp\htdocs\gurpal\application\controllers\Admin.php 1043
ERROR - 2021-04-17 17:21:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:21:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:21:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:21:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:22:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:22:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:22:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:22:56 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:23:53 --> 404 Page Not Found: Admin/edit_product
ERROR - 2021-04-17 17:32:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:32:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:32:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:32:24 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:41:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:41:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:41:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:41:55 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:09 --> Severity: Notice --> Undefined variable: admins E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 74
ERROR - 2021-04-17 17:42:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 74
ERROR - 2021-04-17 17:42:09 --> Severity: Notice --> Undefined variable: categories E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 108
ERROR - 2021-04-17 17:42:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 108
ERROR - 2021-04-17 17:42:09 --> Severity: Notice --> Undefined variable: brands E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 119
ERROR - 2021-04-17 17:42:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 119
ERROR - 2021-04-17 17:42:09 --> Severity: Notice --> Undefined variable: gst E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 130
ERROR - 2021-04-17 17:42:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 130
ERROR - 2021-04-17 17:42:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:10 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:53 --> Severity: Notice --> Undefined variable: admins E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 74
ERROR - 2021-04-17 17:42:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 74
ERROR - 2021-04-17 17:42:53 --> Severity: Notice --> Undefined variable: categories E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 108
ERROR - 2021-04-17 17:42:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 108
ERROR - 2021-04-17 17:42:53 --> Severity: Notice --> Undefined variable: brands E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 119
ERROR - 2021-04-17 17:42:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 119
ERROR - 2021-04-17 17:42:53 --> Severity: Notice --> Undefined variable: gst E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 130
ERROR - 2021-04-17 17:42:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 130
ERROR - 2021-04-17 17:42:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:42:53 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:43:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:43:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:43:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:43:27 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:43:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 74
ERROR - 2021-04-17 17:43:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:43:29 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:43:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 17:43:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:20 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 74
ERROR - 2021-04-17 18:33:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:23 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:28 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:40 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:42 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:46 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:49 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:33:54 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:34:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:34:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:34:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:34:47 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:34:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:34:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:34:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:34:50 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:40:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:40:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:40:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:40:26 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\application\views\admin\products\edit_product.php 74
ERROR - 2021-04-17 18:40:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:40:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:40:30 --> 404 Page Not Found: Admin/img
ERROR - 2021-04-17 18:40:30 --> 404 Page Not Found: Admin/img
