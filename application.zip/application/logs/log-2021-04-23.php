<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-23 06:53:18 --> Severity: error --> Exception: Call to undefined method Home_model::get_banners_active() E:\xampp\htdocs\gurpal\application\controllers\Home.php 17
ERROR - 2021-04-23 06:54:25 --> Severity: error --> Exception: Call to undefined method Home_model::get_banners() E:\xampp\htdocs\gurpal\application\controllers\Home.php 16
ERROR - 2021-04-23 06:54:58 --> Severity: error --> Exception: Call to undefined method Home_model::get_brands_active() E:\xampp\htdocs\gurpal\application\controllers\Home.php 17
ERROR - 2021-04-23 06:55:22 --> 404 Page Not Found: Dmin/index
ERROR - 2021-04-23 06:55:27 --> Severity: Compile Error --> Cannot redeclare Admin::update_brand() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 3848
ERROR - 2021-04-23 13:25:50 --> Severity: Notice --> Undefined index: profile_name E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 48
ERROR - 2021-04-23 13:25:50 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 49
ERROR - 2021-04-23 13:25:50 --> Severity: Notice --> Undefined index: active E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 51
ERROR - 2021-04-23 13:26:04 --> Severity: Notice --> Undefined index: profile_name E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 48
ERROR - 2021-04-23 13:26:04 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 49
ERROR - 2021-04-23 13:26:04 --> Severity: Notice --> Undefined index: active E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 51
ERROR - 2021-04-23 14:10:07 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1542
ERROR - 2021-04-23 14:10:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Array' at line 1 - Invalid query: INSERT INTO `tbl_service_pricing` () VALUES ('5000',2,1,'6000','40','2 person','Per Day'), Array
ERROR - 2021-04-23 14:15:23 --> Query error: Unknown column 'quantity' in 'field list' - Invalid query: INSERT INTO `tbl_service_pricing` (`discount_price`, `fk_service_id`, `is_default`, `original_price`, `quantity`, `service_subvariation`, `service_variation`) VALUES ('500',3,1,'1120','10','2 person','Per Day')
ERROR - 2021-04-23 14:20:32 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1542
ERROR - 2021-04-23 14:20:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Array' at line 1 - Invalid query: INSERT INTO `tbl_service_pricing` () VALUES ('900',4,1,'1120','2 person','Per Day'), Array
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1566
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> sort() expects parameter 1 to be array, null given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1567
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1595
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1566
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> sort() expects parameter 1 to be array, null given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1567
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, integer given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> array_diff(): Argument #1 is not an array E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1572
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1579
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1584
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\gurpal\system\database\DB_query_builder.php 1595
ERROR - 2021-04-23 14:23:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\gurpal\system\core\Exceptions.php:271) E:\xampp\htdocs\gurpal\system\helpers\url_helper.php 564
ERROR - 2021-04-23 14:23:58 --> Severity: Warning --> unlink(.uploads/service/Capture1.PNG): No such file or directory E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 1318
ERROR - 2021-04-23 14:24:02 --> Severity: Warning --> unlink(.uploads/service/Capture2.PNG): No such file or directory E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 1318
ERROR - 2021-04-23 14:24:09 --> Severity: Warning --> unlink(.uploads/service/Capture.PNG): No such file or directory E:\xampp\htdocs\gurpal\application\models\admin\Admin_model.php 1318
ERROR - 2021-04-23 14:24:58 --> Severity: Notice --> Undefined variable: pricing E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 149
ERROR - 2021-04-23 14:36:27 --> Severity: Notice --> Undefined index: pk_price_id E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 174
ERROR - 2021-04-23 14:36:27 --> Severity: Notice --> Undefined index: pk_price_id E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 177
ERROR - 2021-04-23 14:36:27 --> Severity: Notice --> Undefined index: pk_price_id E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 174
ERROR - 2021-04-23 14:36:27 --> Severity: Notice --> Undefined index: pk_price_id E:\xampp\htdocs\gurpal\application\views\admin\services\edit_service.php 177
ERROR - 2021-04-23 14:37:25 --> Query error: Unknown column 'pk_price_id' in 'where clause' - Invalid query: UPDATE `tbl_service_pricing` SET `original_price` = '1150'
WHERE `pk_price_id` = '12'
ERROR - 2021-04-23 14:37:44 --> Query error: Unknown column 'pk_price_id' in 'where clause' - Invalid query: UPDATE `tbl_service_pricing` SET `original_price` = '1155'
WHERE `pk_price_id` = '12'
ERROR - 2021-04-23 15:37:04 --> 404 Page Not Found: Admin/admisn
ERROR - 2021-04-23 15:37:06 --> Severity: Notice --> Undefined index: profile_name E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 48
ERROR - 2021-04-23 15:37:06 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 49
ERROR - 2021-04-23 15:37:06 --> Severity: Notice --> Undefined index: active E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 51
ERROR - 2021-04-23 15:42:25 --> Severity: Notice --> Undefined index: admin_email E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 49
ERROR - 2021-04-23 15:42:25 --> Severity: Notice --> Undefined index: active E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 51
ERROR - 2021-04-23 15:43:12 --> Severity: Notice --> Undefined index: active E:\xampp\htdocs\gurpal\application\views\admin\admins\admins.php 51
ERROR - 2021-04-23 15:43:53 --> Severity: error --> Exception: Call to undefined method Admin_model::check_admin_id() E:\xampp\htdocs\gurpal\application\controllers\Admin.php 3954
ERROR - 2021-04-23 16:08:14 --> Severity: Notice --> Undefined index: states_name E:\xampp\htdocs\gurpal\application\views\admin\admins\edit_admin.php 74
ERROR - 2021-04-23 16:11:02 --> 404 Page Not Found: Admin/admisn
ERROR - 2021-04-23 16:11:08 --> Severity: Notice --> Undefined index: states_name E:\xampp\htdocs\gurpal\application\views\admin\admins\edit_admin.php 74
ERROR - 2021-04-23 16:13:39 --> 404 Page Not Found: Admin/admisn
ERROR - 2021-04-23 16:32:05 --> 404 Page Not Found: Admin/admisn
ERROR - 2021-04-23 16:32:08 --> 404 Page Not Found: Admin/admisn
ERROR - 2021-04-23 16:33:26 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\gurpal\system\database\DB_driver.php 1519
ERROR - 2021-04-23 16:33:26 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\gurpal\system\database\DB_driver.php 1519
ERROR - 2021-04-23 16:33:26 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `tbl_admin_profile` SET `profile_categories` = Array, `profile_states` = NULL, `profile_cities` = Array
WHERE `fk_admin_id` = '4'
ERROR - 2021-04-23 16:35:32 --> Severity: Warning --> implode(): Invalid arguments passed E:\xampp\htdocs\gurpal\application\controllers\Admin.php 4024
